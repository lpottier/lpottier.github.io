echo "-- Generate vary-p..."
./plot.py -csv output/new_amdahl/vary-p/random-n-16to16_p-1to256-Cs-32000000000.0_ls-0.17_alpha-0.5.csv -xaxis p -short -norm 0
./plot.py -csv output/new_amdahl/vary-p/multinpbs-n-16to16_p-1to256-Cs-32000000000.0_ls-0.17_alpha-0.5.csv -xaxis p -short -norm 0
./plot.py -csv output/new_amdahl/vary-p/multinpbs-n-64to64_p-1to256-Cs-32000000000.0_ls-0.17_alpha-0.5.csv -xaxis p -short -norm 0
./plot.py -csv output/new_amdahl/vary-p/random-n-64to64_p-1to256-Cs-32000000000.0_ls-0.17_alpha-0.5.csv -xaxis p -short -norm 0
./plot.py -csv output/new_amdahl/vary-p/npbs-n-6to6_p-1to256-Cs-32000000000.0_ls-0.17_alpha-0.5.csv -xaxis p -short -norm 0

echo "-- Generate vary-p normalized with DominantMinRatio..."
./plot.py -csv output/new_amdahl/vary-p-domratio/multinpbs-n-16to16_p-1to256-Cs-32000000000.0_ls-0.17_alpha-0.5-domratio.csv -xaxis p -short -noshed -norm 0
./plot.py -csv output/new_amdahl/vary-p-domratio/multinpbs-n-64to64_p-1to256-Cs-32000000000.0_ls-0.17_alpha-0.5-domratio.csv -xaxis p -short -noshed -norm 0
./plot.py -csv output/new_amdahl/vary-p-domratio/random-n-16to16_p-1to256-Cs-32000000000.0_ls-0.17_alpha-0.5-domratio.csv -xaxis p -short -noshed -norm 0
./plot.py -csv output/new_amdahl/vary-p-domratio/random-n-64to64_p-1to256-Cs-32000000000.0_ls-0.17_alpha-0.5-domratio.csv -xaxis p -short -noshed -norm 0
./plot.py -csv output/new_amdahl/vary-p-domratio/npbs-n-6to6_p-1to256-Cs-32000000000.0_ls-0.17_alpha-0.5-domratio.csv -xaxis p -short -noshed -norm 0

echo "-- Generate vary-n..."
./plot.py -csv output/new_amdahl/vary-n/multinpbs-n-1to256_p-256to256-Cs-32000000000.0_ls-0.17_alpha-0.5.csv -xaxis n -short -norm 0
./plot.py -csv output/new_amdahl/vary-n/random-n-1to256_p-256to256-Cs-32000000000.0_ls-0.17_alpha-0.5.csv -xaxis n -short -norm 0
./plot.py -csv output/new_amdahl/vary-n/random-n-1to256_p-256to256-Cs-32000000000.0_ls-0.17_alpha-0.5-average.csv -xaxis n+ -noshed -short -norm 0
./plot.py -csv output/new_amdahl/vary-n/multinpbs-n-1to256_p-256to256-Cs-32000000000.0_ls-0.17_alpha-0.5-average.csv -xaxis n+ -noshed -short -norm 0

echo "**-- Generate vary-n but only with dom part..."
./plot_dom.py -csv output/new_amdahl/vary-n/multinpbs-n-1to256_p-256to256-Cs-32000000000.0_ls-0.17_alpha-0.5-normalizeddom.csv -xaxis n -dom -norm 0
./plot_dom.py -csv output/new_amdahl/vary-n/random-n-1to256_p-256to256-Cs-32000000000.0_ls-0.17_alpha-0.5-normalizeddom.csv -xaxis n -dom -norm 0

echo "-- Generate vary-n normalized with DominantMinRatio..."
./plot.py -csv output/new_amdahl/vary-n-domratio/multinpbs-n-1to256_p-256to256-Cs-32000000000.0_ls-0.17_alpha-0.5-domratio.csv -xaxis n -short -noshed -norm 0
./plot.py -csv output/new_amdahl/vary-n-domratio/random-n-1to256_p-256to256-Cs-32000000000.0_ls-0.17_alpha-0.5-domratio.csv -xaxis n -short -noshed -norm 0

echo "**-- Generate vary-miss but only with dom part..."
./plot_dom.py -csv output/new_amdahl/vary-miss/varymiss-n-16to16_p-256to256-Cs-1000000000.0_ls-0.17_alpha-0.5.csv -xaxis m -dom -noshed -norm 1

echo "Generate vary-ls..."
./plot.py -csv output/new_amdahl/vary-ls/varyls-n-16to16_p-256to256-Cs-32000000000.0_ls-0.0_alpha-0.5_fs-0.0001.csv -xaxis ls -short -norm 0
./plot.py -csv output/new_amdahl/vary-ls/varyls-n-64to64_p-256to256-Cs-32000000000.0_ls-0.0_alpha-0.5_fs-0.0001.csv -xaxis ls -short -norm 0
./plot.py -csv output/new_amdahl/vary-ls/varyls-n-128to128_p-256to256-Cs-32000000000.0_ls-0.0_alpha-0.5_fs-0.0001.csv -xaxis ls -short -norm 0

echo "-- Generate vary-s..."
./plot.py -csv output/new_amdahl/vary-s/multinpbs-n-16to16_p-256to256-Cs-32000000000.0_ls-0.17_alpha-0.5_fs-0.0.csv -xaxis s -short -norm 0
./plot.py -csv output/new_amdahl/vary-s/random-n-16to16_p-256to256-Cs-32000000000.0_ls-0.17_alpha-0.5_fs-0.0.csv -xaxis s -short -norm 0
./plot.py -csv output/new_amdahl/vary-s/npbs-n-6to6_p-256to256-Cs-32000000000.0_ls-0.17_alpha-0.5_fs-0.0.csv -xaxis s -short -norm 0

echo "-- Generate vary-s with Dominant Ratio"
./plot.py -csv output/new_amdahl/vary-s-domratio/multinpbs-n-16to16_p-256to256-Cs-32000000000.0_ls-0.17_alpha-0.5_fs-0.0-domratio.csv -xaxis s -short -noshed -norm 0
./plot.py -csv output/new_amdahl/vary-s-domratio/npbs-n-6to6_p-256to256-Cs-32000000000.0_ls-0.17_alpha-0.5_fs-0.0-domratio.csv -xaxis s -short -noshed -norm 0
./plot.py -csv output/new_amdahl/vary-s-domratio/random-n-16to16_p-256to256-Cs-32000000000.0_ls-0.17_alpha-0.5_fs-0.0-domratio.csv -xaxis s -short -noshed -norm 0
