#!/usr/local/bin/python3 
#Author: Loïc Pottier


from math import pow
import random
import sys
import statistics

epsilon = pow(50, -6)

##### Variables #####
### Constants
N = 1 # Number of tasks
P = 1 # Number of processors
Cs = 's' # Small storage size (MB)
ls = 's' # Small storage latency

Cl = 's' # Large storage size (MB)
ll = 's' # Large storage latency

alpha = 0.5 # Parameter for Power Law (0.3 <= alpha <= 07)

### Arrays (value for each application)
w = [] # Number of computing operations
f = [] # Frequency of data acessess
a = [] # Data footprint (not used right now)
m1MBSs = [] # Rate of cache miss for a 1MB cache
d = [] # For simplification : d[i] = m1MBSs[i] * pow((pow(10,6)/Cs), alpha)
fs = [] # seqential fraction

# What we want to find
#x = [] # Fraction of cache allocated 
#p = [] # Number of processors allocated

def init_constants(cs_, ls_, cl_, ll_, alpha_):
        global Cs,Cl,ls,ll,alpha
        
        assert cs_ > pow(10,6)
        assert cs_ < cl_
        assert alpha_ <= 1
        
        Cs = cs_
        ls = ls_
        Cl = cl_
        ll = ll_
        alpha = alpha_
        

### Initialisation of data

def init_random(n, inf, sup, integer=False):
        if integer:
                return [random.randint(inf,sup) for i in range(n)]
        else:
                return [random.uniform(inf, sup) for i in range(n)]
        
### Model functions

# Sequential execution time for tasks Ti with xi fraction of cache
def exeseq(i,xi):
        assert 0 <= xi <= 1
        if xi > 0:
                return w[i] * ( 1 + f[i] * (ls + ll * min(1, d[i]/pow(xi,alpha)) ) )
        else:
                return w[i] * ( 1 + f[i] * (ls + ll ) )


# Execution time for tasks Ti with pi processors and xi fraction of cache and fs fraction of sequential code
def exe(i, xi, pi, fs):
        return fs * exeseq(i,xi) + (1-fs) * exeseq(i,xi) / pi

def opt_xi(i, Ic):
        acc = 0
        if i in Ic:
                for j in Ic:
                        acc += pow(w[j]*f[j]*d[j], 1/(alpha+1))
                return pow(w[i]*f[i]*d[i], 1/(alpha+1)) / acc
        else:
                return 0.0

def compute_xi(n_, Ic):
        res = list(range(n_))
        for i in range(n_):
                res[i] = opt_xi(i, Ic)
        #print ("xi : sum(res) = {} and epsilon = {} -> 1 + epsilon = {}".format(sum(res), epsilon, 1+epsilon))
        assert sum(res) < 1+epsilon
        return res

def check_xi(xi):
        for e in xi:
                if pow(d[i], 1/alpha) >= e:
                        return False
        return True

def compute_pi(n_, p_, xi):
        res = list(range(n_))
        acc = 0
        for j in range(n_):
                acc += exeseq(j, xi[j])
        for i in range(n_):
                res[i] = p_ * exeseq(i, xi[i]) / acc
        #print ("pi : sum(res) = {} and epsilon = {} -> p_ + epsilon = {}".format(sum(res), epsilon, p_+epsilon))
        assert sum(res) < p_ + epsilon
        #print (res)
        return res

#Function needed just to clean the code
def Y(n_, xi, Ic, mksp, fs):
        acc = 0
        for i in range(n_):
                if i in Ic:
                        c = 1 + f[i] * (ls + ll * d[i]/pow(xi[i],alpha))                        
                else:
                        c = 1 + f[i] * (ls + ll)
                acc = acc + (w[i] * (1 - fs[i])) / ((mksp / c) - w[i]*fs[i] )
        return acc

def check_pi(P, pi):
        for e in pi:
                if e < 0 or e > P+0.1:
                        return False
        return True

def compute_pi_amdahl(n_, p_, xi, fs, Ic, seuil=1):
        pi_perfect = compute_pi(n_, p_, xi)
        
        K_min = max([exe(i, xi[i], p_, fs[i]) for i in range(n_)])
        K_max = max([exe(i, xi[i], seuil, fs[i]) for i in range(n_)])

        K = K_min + (K_max - K_min)/2

        epsilon = 0.01

        i = 4
        
        while True:
                val = Y(n_, xi, Ic, K, fs)
                #print ("K={} K_min={} and K_max={} || K_max-K_min={}".format(K, K_min, K_max, K_max-K_min))
                #print ("Y({})={} vs p_={}".format(K, Y(n_, xi, Ic, K, fs), p_)) 
                #print ("Y_min({})={} vs Y_max=({})={}      and K_max - K = {}".format(K_min, Y(n_, xi, Ic, K_min, fs), K_max, Y(n_, xi, Ic, K_max, fs), K_max-K)) 
                #print ("---- {} -----".format(i)) 
                
                if val > p_ + epsilon:
                        K = K + K/i
                elif val < p_ - epsilon:
                        K = K - K/i
                else:
                        #print("WIIIIINNNNNN")
                        break

                i = i + 2
        
        pi_amdahl = [0]*n_
        for i in range(n_):
                if i in Ic:
                        c = 1 + f[i] * (ls + ll * min(1, d[i]/pow(xi[i],alpha)) )                        
                else:
                        c = 1 + f[i] * (ls + ll)
                pi_amdahl[i] = (w[i] * (1 - fs[i])) / ((K / c) - w[i]*fs[i] )
                

        try:
                assert check_pi(p_, pi_amdahl)
        except AssertionError:
                print ("--------   ERROR in pi")
                print ("pi_perfect={}".format(pi_perfect))
                print ("pi_amdahl={}".format(pi_amdahl))
                print ("--------------------------------")
                
                pi_amdahl = compute_pi_amdahl(n_, p_, xi, fs, Ic, 0.1)
                print ("new pi_amdahl={}".format(pi_amdahl))

        return pi_amdahl

def bigsum(I):
        acc=0
        for j in I:
                acc += pow(w[j]*f[j]*d[j], 1/(alpha+1))
        return acc

#compute sum_{i \in Ic} (wi fi di)^{1/(alpha+1)}
def compute_C(Ic):
        acc = 0
        for j in Ic:
                acc += pow(w[j]*f[j]*d[j], 1/(alpha+1))
        return acc

# Return true if I is a dominant partition
def is_dominant(I):
        for i in I:
                if pow(w[i]*f[i]*d[i], 1/(alpha+1)) / bigsum(I) <= pow(d[i], 1/alpha) :
                        #print ("i={} : w/d {} >= bigsum = {}".format(i, pow(w[i]*f[i]*d[i], 1/(alpha+1)) / pow(d[i], 1/alpha), bigsum(I)))
                        #print ("----- w/sum {} and di = {}".format(pow(w[i]*f[i]*d[i], 1/(alpha+1))/ bigsum(I), pow(d[i], 1/alpha)))
                        return False
        return True

#Build a dominant partition
def build_dominant_partition(n, func):
        Ic = set(range(n))

        while not is_dominant(Ic):
                i = func(Ic) # Choice function
                Ic = Ic - {i}
                if len(Ic) == 0:
                        break

        Icbar = set(range(n)) - Ic

        assert len(Ic)+len(Icbar) == n
        try:
                assert is_dominant(Ic)
        except AssertionError:
                print ("NOT DOMINANT : len(Ic)= {} and {} (i={})".format(len(Ic), Ic, i))
                print (is_dominant(Ic))
                #print("****** Icprime {} {}".format(Icprime, is_dominant(Icprime)))
                # print (is_dominant2(Icprime))
                # print (w,f,d)
                # print ("-----------")
        return (Ic,Icbar)

# Reverse order
def build_dominant_partition_rev(n, func):
        Icbar = set(range(n))
        i = func(Icbar) # Choice function
        Ic = set()
        Icprime = {i}

        while is_dominant(Icprime):
                Ic = Icprime
                Icbar = Icbar - {i}
                if len(Icbar) == 0:
                        break
                i = func(Icbar) # Choice function
                Icprime = Icprime | {i}

        assert len(Ic)+len(Icbar) == n
        try:
                assert is_dominant(Ic)
        except:
                print ("REV NOT DOMINANT : len(Ic)= {}".format(len(Ic)))
                print (Ic)
        
        return (Ic,Icbar)

### Choices function for f
def f_random(I):
        value = random.sample(I, 1)
        return value[0]

def f_min_ratio(I):
        res = {}
        for i in I:
                res[i] = pow(w[i]*f[i]*d[i], 1/(alpha+1)) / pow(d[i], 1/alpha)
        try:
                assert len(res) !=0
        except:
                print("len(I) = {}, len(res) = {}".format(len(I), len(res)))
        return min(res, key=res.get)

def f_max_ratio(I):
        res = {}
        for i in I:
                res[i] = pow(w[i]*f[i]*d[i], 1/(alpha+1)) / pow(d[i], 1/alpha)
        try:
                assert len(res) !=0
        except:
                print("len(I) = {}, len(res) = {}".format(len(I), len(res)))
        return max(res, key=res.get)

def f_min_wifidi(I):
        res = {}
        for i in I:
                res[i] = w[i]*f[i]*d[i]
        try:
                assert len(res) !=0
        except:
                print("len(I) = {}, len(res) = {}".format(len(I), len(res)))
        return min(res, key=res.get)

### Others heuristics (fair heurstics)

def build_random_partition(n, func):
        x = random.randint(0,n)
        I = set(random.sample(list(range(n)), x)) #Take randomly a subset of size x
        Ibar = set(range(n)) - I
        return (I,Ibar)

### Scheduling functions

# All tasks executed with maximum number of processors and the whole caches
def best_scheduling(n_, p_, fs):
        tps = list(range(n_))
        for i in range(n_):
                tps[i] = exe(i, 1.0, p_, fs[i]) #Whole cache and max number of processors
        #print ("func={} tab={} res={}".format("allproccache", tps, sum(tps)))
        return (sum(tps),[1]*n_,[p_]*n_,fs)

###### TODO fair heuristics

def coschedcache_equal(n_, p_, fs):
        xi = [1/n_]*n_ # equals fraction of cache
        pi = [p_ / n_ ] * n_ # equals fraction of proc
        mksp = cosched_mksp(n_, xi, pi, fs)

        #tps = list(range(n_))
        #for i in range(n_):
        #        tps[i] = exe(i, xi[i], pi[i], fs[i]) #Whole cache and max number of processors

        #print ("func={} xi={} pi={} tps={} sum(tps)={}".format("equal",xi,pi , tps, sum(tps)))
        return mksp

def coschedcache_fair(n_, p_, fs):
        xi = list(range(n_))
        for i in range(n_):
                xi[i] = f[i] / sum(f)

        #print ("xi fair {}".format(xi))
        pi = [p_ / n_ ] * n_ # equals fraction of proc
        mksp = cosched_mksp(n_, xi, pi, fs)
        return mksp

def coschedcache_0cache(n_, p_, fs):
        xi = [0.0]*n_
        #pi = compute_pi(n_, p_, xi)
        pi = compute_pi_amdahl(n_, p_, xi, fs, set())

        #pi = [p_ / n_ ] * n_ # equals fraction of proc
        mksp = cosched_mksp(n_, xi, pi, fs)
        return mksp


#compute the makspan of a schedule according to xi and pi
def cosched_mksp(n_, xi, pi, fs):
        tps = list(range(n_))
        for i in range(n_):
                tps[i] = exe(i, xi[i], pi[i], fs[i]) #Whole cache and max number of processors

#        mean = statistics.mean(tps)
#        max_tps = max(tps)
#        epsilon = pow(10,-2)
#        print (mean,max_tps,epsilon)
#        print (pi)
#        assert (mean < max_tps+epsilon) and (mean > max_tps-epsilon)

#        print ("func={} xi={} pi={} tab={}    res={}".format("cosched_mksp",xi,pi , tps, max(tps)))
        
        return (max(tps),xi,pi,fs)


#Cosched cache with dominant partition : return the makespan according the heuristics used and initialisation of parameters and constants 
def coschedcache_dompart(n_, p_, func_heuristics, func_choice, fs):
        (Ic, Icbar) = func_heuristics(n_, func_choice)
        xi = compute_xi(n_, Ic)
        #pi = compute_pi(n_, p_, xi)
        pi = compute_pi_amdahl(n_, p_, xi, fs, Ic)

        #if func_heuristics==build_dominant_partition:
        #        print ("DOMPART")
        #        print (Ic,Icbar)
        #        print (func_heuristics, func_choice)
        #        print (xi)
        #        print (pi)
        #        print ("-------")

        mksp = cosched_mksp(n_, xi, pi, fs)
        #print (xi,pi)
        return (mksp, len(Ic), len(Icbar))


#Return [[mksp, pi, xi, fs] for each heuristics]
def simulation(n_, p_, cs_, ls_, cl_, ll_, alpha_, w_, f_, m1MBSs_, s_, size_base_line):
        global N,P, w, f, a, m1MBSs, d, s, fs
        N = n_
        P = p_
        init_constants(cs_, ls_, cl_, ll_, alpha_)
        w = w_
        f = f_
        m1MBSs = m1MBSs_
        fs = s_
        
        d = [m1MBSs_[i] * pow((size_base_line * pow(10,6))/Cs, alpha) for i in range(n_)]

        #print ("--------- w")
        #print (w)
        #print ("--------- f")
        #print (f)
        #print ("--------- m1mbss")
        #print (m1MBSs)

        assert len(w) > 0
        assert len(f) > 0
        assert len(m1MBSs_) > 0
        
        mksp_best = best_scheduling(N, P, fs)

        ## Dominant partition
        mksp_rnd = coschedcache_dompart(N,P, build_dominant_partition, f_random, fs)
        mksp_min_ratio = coschedcache_dompart(N,P, build_dominant_partition, f_min_ratio, fs)
        mksp_max_ratio = coschedcache_dompart(N,P, build_dominant_partition, f_max_ratio, fs)
        mksp_wifidi = coschedcache_dompart(N,P, build_dominant_partition, f_min_wifidi, fs)[0]
        #mksp_wifidi = [0.0,0.0,0.0,0.0]
        
        mksp_rev_rnd = coschedcache_dompart(N,P, build_dominant_partition_rev, f_random, fs)
        mksp_rev_min_ratio = coschedcache_dompart(N,P, build_dominant_partition_rev, f_min_ratio, fs)
        mksp_rev_max_ratio = coschedcache_dompart(N,P, build_dominant_partition_rev, f_max_ratio, fs)
        mksp_rev_wifidi = coschedcache_dompart(N,P, build_dominant_partition_rev, f_min_wifidi, fs)[0]
        #mksp_rev_wifidi = [0.0,0.0,0.0,0.0]

        ## Random partition
        mksp_random = coschedcache_dompart(N,P, build_random_partition, f_random, fs)
        
        ## Fair heurisitics
        mksp_equal = coschedcache_equal(N, P, fs)
        #mksp_equal = [0.0,0.0,0.0,0.0]
        mksp_fair = coschedcache_fair(N, P, fs)
        
        mksp_0cache = coschedcache_0cache(N, P, fs)

        data = [mksp_best, mksp_rnd[0], mksp_min_ratio[0], mksp_max_ratio[0], mksp_wifidi, mksp_rev_rnd[0], mksp_rev_min_ratio[0], mksp_rev_max_ratio[0], mksp_rev_wifidi, mksp_random[0], mksp_equal, mksp_fair, mksp_0cache]
        
        tab_min_xi = [min(e[1]) for e in data]
        tab_max_xi = [max(e[1]) for e in data]
        tab_average_xi = [statistics.mean(e[1]) for e in data]
        
        tab_min_pi = [min(e[2]) for e in data]
        tab_max_pi = [max(e[2]) for e in data]
        tab_average_pi = [statistics.mean(e[2]) for e in data]
        
        return ([e[0] for e in data] , [tab_min_pi, tab_max_pi, tab_average_pi], [tab_min_xi, tab_max_xi, tab_average_xi])


# def main(argv):
#         (ww, ff, m1MBSsBIS) = init_all_random(100, 0, 10)
#         res = simulation(100, 25, 10000000, 0.001, 10000000000, 1, 0.5, ww, ff, m1MBSsBIS,)
#         print(res)
        
# if __name__ == "__main__":
# 	main(sys.argv[1:])
