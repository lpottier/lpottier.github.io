#!/usr/local/bin/python3
#Author: Loïc Pottier


import matplotlib.pyplot as plt
import matplotlib.patches as patches
import matplotlib.colors as colors
from matplotlib import rc
from matplotlib.ticker import FormatStrFormatter

import itertools
import argparse
import sys
import csv
import os

plt.rcParams['figure.figsize'] = 9, 4.5
rc('text', usetex=True)


def box_plot(data, out_file):

    fig, ax = plt.subplots(1, 1)

    plt.rc('text', usetex=True)
    plt.rc('font', family='Computer Modern', size='10')

    #plt.style.use('ggplot')
    #plt.style.use(['dark_background'])
    
    for exp in data:
        ax.boxplot(exp)
    
    fig.savefig(out_file)
    plt.close(fig)

def plot(data, out_file, step, Xaxis, labels, norm, noshed):


    if Xaxis == 'n+':
        #Add nb_proc/nb_tasks instead of fs field (field 5)
        for i in range(len(data)):
            data[i][5] = float(data[i][1]) / float(data[i][0])
        #data = data[2:]
    if Xaxis == 'n-':
        #Add nb_task/nb_proc instead of fs field (field 5)
        for i in range(len(data)):
            data[i][5] = float(data[i][0]) / float(data[i][1])
        #data = data[2:]
            
    data_col = [ [x[j] for x in data] for j in range(len(data[0])) ]
     
    if Xaxis == 'n':
        name_xaxis = '\#Applications'
        X = list(map(int,data_col[0])) #tasks
    elif Xaxis == 'p':
        name_xaxis = '\#Processors'
        X = list(map(int,data_col[1])) #procs
    elif Xaxis == 's':
        name_xaxis = 'Sequential part'
        if noshed:
            X = list(map(float,data_col[5])) #f_s
        else:
            X = list(map(float,data_col[5])) #f_s
        print (X)
    elif Xaxis == 'm':
        name_xaxis = 'Cache miss rate'
        if not noshed:
            X = list(map(float,data_col[4])) #dans le cas varying miss, le args.alpha est remplacé par m1MBSs 3 si norm, 4 sinon
        else:
            X = list(map(float,data_col[3]))
        print (X)
    elif Xaxis == 'ls':
        name_xaxis = r'$l_s$ value'
        if not noshed:
            X = list(map(float,data_col[3])) #dans le cas varying miss, le args.alpha est remplacé par m1MBSs 3 si norm, 4 sinon
        else:
            X = list(map(float,data_col[3]))
        print (X)
    elif Xaxis == 'n+':
        name_xaxis = r'$\frac{\#Processors}{\#Applications}$'
        X = list(map(float,data_col[5])) #tasks
        #[256/float(x) for x in X]
    elif Xaxis == 'n-':
        name_xaxis = r'$\frac{\#\text{Applications}}{\#\text{Processors}}$'
        X = list(map(float,data_col[5])) #tasks
        #[256/float(x) for x in X]

    data_col = [list(map(float,e)) for e in data_col[6:]] # Convert char to float for results

    fig, ax = plt.subplots(1, 1)
    
    #Normalized with col norm
    if norm != None:
        allproccache = data_col[norm]
        data_normalized = []
        pos=1 #legend
        ax.set_ylabel('Normalized Makespan')
        for i in range(len(data_col)):
            tmp = []
            for j in range(len(data_col[0])):
                tmp.append(data_col[i][j] / allproccache[j])
            data_normalized.append(tmp)
        data_col = data_normalized
    else:
        ax.set_ylabel('Makespan')
        pos=2

    i = 0
    styles = itertools.cycle(['o', 's', 'D', '8', 'p', '*', 'x', 'h', '+', 'v', '<', '>','d'])
    c = itertools.cycle(['r', 'b', 'g', 'c', 'm', 'y', 'k', 'y', 'b'])

    if noshed and norm != None:
        next(styles)
        next(c)

    plt.rc('text', usetex=True)
    plt.rc('font', family='Computer Modern', size='10')

    #plt.style.use('ggplot')
    #plt.style.use(['dark_background'])

    # set the x and y labels
    ax.set_xlabel(name_xaxis)
    # set the xlim
    ax.set_xlim(min(X), max(X))


    if Xaxis == 'n':
        ax.set_xscale('log')
        ax.xaxis.set_major_formatter(FormatStrFormatter("%.0f"))
    
    if Xaxis in ['n+', 'n-']:
        ax.set_xscale('log')
        ax.xaxis.set_major_formatter(FormatStrFormatter("%.0f"))
        ax.grid()
    ax.set_xticks(X, minor=True)


    for exp in data_col:
        ax.plot(X, exp, color=next(c), marker=next(styles), alpha=1.00, label=labels[i], markevery=step, markersize=4)
        i = i + 1

    ax.set_yticks([0.999+0.001*i for i in range(0,11)],minor=True)
    ax.get_yaxis().get_major_formatter().set_useOffset(False)
    #ax.grid()
    #ax.legend(frameon=False, loc='upper right', ncol=2)

    box = ax.get_position()
    ax.set_position([box.x0, box.y0, box.width, box.height * 0.8])
    # Put a legend to the right of the current axis
    #ax.legend(loc='upper center', bbox_to_anchor=(1, 0.5))
    ax.legend(loc='upper center', bbox_to_anchor=(0.5, 1.25), ncol=3, frameon=False, fancybox=True, shadow=False)


    fig.savefig(out_file)
    plt.close(fig)


if __name__ == "__main__":
    
    parser = argparse.ArgumentParser()
    parser.add_argument('-csv', type=str, help="Path of csv data")
    parser.add_argument('-xaxis', type=str, default='t', help="X axis: 't' for tasks, 'p' for processors")
    parser.add_argument('-norm', type=int, help="Normalized all results with col")
    parser.add_argument('-short', default=False, help="Plot a subset of heuristics", action='store_true')
    parser.add_argument('-dom', default=False, help="Plot only dominant partitions based heuristics", action='store_true')
    parser.add_argument('-step', type=int, default=1, help="Plot a value very step")
    parser.add_argument('-noshed', default=False, help="Without AllProcCache", action='store_true')

    args = parser.parse_args()

    if len(sys.argv[1:]) < 1:
        parser.print_help()
        parser.exit()

    if args.short and args.dom:
        parser.print_help()
        parser.exit()
    
    if args.step < 1:
        args.step = 1
    
    with open(args.csv, newline='') as csvfile:
        reader = csv.reader(csvfile, delimiter=' ')
        data = []
        for row in reader:
            data.append(row)

        #Delete Equal
        data = [x[:16]+x[-2:] for x in data]
        #Remove min Winfidi
        data = [x[:10]+x[-7:] for x in data]
        #Remove Rev min wifidi
        data = [x[:13]+x[-3:] for x in data]
            
        if args.short:
            labels = [r'\textsc{AllProcCache}', r'\textsc{DominantMinRatio}', r'\textsc{RandomPart}', r'\textsc{Fair}', r'\textsc{Ocache}']
            data = [x[:7]+[x[8]]+x[-3:] for x in data] #on garde que les heuristics correspondant aux labels
        elif args.dom:
            labels = [r'\textsc{AllProcCache}', r'\textsc{DominantRandom}', r'\textsc{DominantMinRatio}', r'\textsc{DominantMaxRatio}', r'\textsc{DominantRevRandom}', r'\textsc{DominantRevMinRatio}', r'\textsc{DominantRevMaxRatio}']
            data = [x[:-4] for x in data]
            #print (data)
        else:
            labels = [r'\textsc{AllProcCache}', r'\textsc{DominantRandom}', r'\textsc{DominantMinRatio}', r'\textsc{DominantMaxRatio}', r'\textsc{DominantRevRandom}', r'\textsc{DominantRevMinRatio}', r'\textsc{DominantRevMaxRatio}', r'\textsc{RandomPart}', r'\textsc{Fair}', r'\textsc{Ocache}']

        #Delete AllProcCache
        if args.noshed:
            labels = labels[1:]
            data = [x[:6]+x[7:] for x in data]

            
        info = data[:1] #nom des heuristiques
        #full_data = data[1:]
        #data = [x[5:] for x in full_data] #que les temps d'exec
        data = data[1:]
        
        filename, file_extension = os.path.splitext(args.csv)
        filename = os.path.basename(filename)

        if args.norm != None:
            plot(data, '../results_amdahl/'+filename+'-normalized.pdf', args.step, args.xaxis, labels, args.norm, args.noshed)
            print ('../results_amdahl/'+filename+'-normalized.pdf')
        else:
            plot(data, '../results_amdahl/'+filename+'.pdf', args.step, args.xaxis, labels, args.norm, args.noshed)
            print('../results_amdahl/'+filename+'.pdf')

    
    
  
