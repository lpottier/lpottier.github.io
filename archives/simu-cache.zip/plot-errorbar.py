#!/usr/local/bin/python3
#Author: Loïc Pottier


import matplotlib.pyplot as plt
import matplotlib.patches as patches
import matplotlib.colors as colors
from matplotlib import rc
from matplotlib.ticker import FormatStrFormatter

import itertools
import argparse
import sys
import csv
import os
import glob

plt.rcParams['figure.figsize'] = 9, 4.5
rc('text', usetex=True)

def errorfill(ax, x, y, yerr, col, lab, alpha_fill):
    if len(yerr) == len(y):
        ymin = y - yerr
        ymax = y + yerr
    elif len(yerr) == 2:
        ymin, ymax = yerr
    ax.plot(x, y, color=col, label=lab)
    ax.fill_between(x, ymax, ymin, color=col, alpha=alpha_fill)


def plot(data, out_file, step, Xaxis, labels, proc=True):
    i = 0
    styles = itertools.cycle(['o', 's', 'D', '8', 'p', '*', 'x', 'h', '+', 'v', '<', '>','d'])
    c = itertools.cycle(['r', 'b', 'g', 'c', 'm', 'y', 'k', 'y', 'b'])

    plt.rc('text', usetex=True)
    plt.rc('font', family='Computer Modern', size='10')
    #plt.style.use('ggplot')
    #plt.style.use(['dark_background'])
    
    if Xaxis == 'n+':
        name_xaxis = r'$\frac{\#Processors}{\#Applications}$'
        X = [float(x[0])/float(x[1]) for x in data[0][1:]]
    else:
        name_xaxis = "\#Applications"
        X = [int(x[0]) for x in data[0][1:]]

    fig, ax = plt.subplots(1, 1)
    # set the x and y labels
    ax.set_xlabel(name_xaxis)
    if proc:
        ax.set_ylabel('Average number of processors')
    else:
        ax.set_ylabel('Average fraction of cache')        
    # set the xlim
    ax.set_xlim(min(X), max(X))
    ax.set_xscale('log')
    ax.xaxis.set_major_formatter(FormatStrFormatter("%.0f"))


    for exp in data:
        #info = exp[0]
        data_numeric = [list(map(float,x[6:])) for x in exp[1:]]

        #Compute the "error" corresponding to min and max
        if proc:
            y_min = [x[2]-x[0] for x in data_numeric]
            y_max = [x[1]-x[2] for x in data_numeric]
            y_avg = [x[2] for x in data_numeric]
        else:
            #Cache version
            y_min = [x[5]-x[3] for x in data_numeric]
            y_max = [x[4]-x[5] for x in data_numeric]
            y_avg = [x[5] for x in data_numeric]

        #col = next(c)
        #errorfill(ax, X, y_avg, [y_min, y_max], col, labels[i], 1)
        ax.errorbar(X, y_avg, yerr=[y_min, y_max], color=next(c), label=labels[i])

        #ax.errorbar(X, exp, color=next(c), marker=next(styles), alpha=1.00, label=labels[i], markevery=step, markersize=4)
        i = i + 1

        #print ("-----------")
        #for e in y_avg:
           #print (e)
    
    box = ax.get_position()
    ax.set_position([box.x0, box.y0, box.width, box.height * 0.8])
    # Put a legend to the right of the current axis
    #ax.legend(loc='upper center', bbox_to_anchor=(1, 0.5))
    ax.legend(loc='upper center', bbox_to_anchor=(0.5, 1.25), ncol=3, frameon=False, fancybox=True, shadow=False)

    fig.savefig(out_file)
    plt.close(fig)


if __name__ == "__main__":

    parser = argparse.ArgumentParser()
    parser.add_argument('-folder', type=str, help="Path of csv data")
    parser.add_argument('-xaxis', type=str, default='t', help="X axis: 't' for tasks, 'p' for processors")
    parser.add_argument('-step', type=int, default=1, help="Plot a value very step")
    parser.add_argument('-dom', default=False, help="Plot only dominant partitions based heuristics", action='store_true')
    parser.add_argument('-minratio', default=False, help="DomMinRation vs Randompart 0cache and Fair", action='store_true')

    args = parser.parse_args()

    #if len(sys.argv[1:]) < 1:
    #    parser.print_help()
    #    parser.exit()

    if args.step < 1:
        args.step = 1

    if args.folder == None:
        args.folder = '.'

    if args.dom and args.minratio:
        parser.print_help()
        parser.exit()

    all_data = []
    all_csv = []
    for files in glob.glob(args.folder+'/*.csv'):
        #Remove useless heuristics
        if 'AllProcCache' in files or 'DominantMinWifidi' in files or 'DominantRevMinWifidi' in files or 'Equals' in files:
            continue
        
        print ("Reading file {}...".format(files))
        all_csv.append(files)
        
        with open(files, newline='') as csvfile:
            reader = csv.reader(csvfile, delimiter=' ')
            data = []
            for row in reader:
                data.append(row)
            all_data.append(data)
        #print (data) 

    labels = [r'\textsc{DominantMaxRatio}', r'\textsc{DominantMinRatio}', r'\textsc{DominantRandom}', r'\textsc{DominantRevMaxRatio}', r'\textsc{DominantRevMinRatio}', r'\textsc{DominantRevRandom}', r'\textsc{Fair}', r'\textsc{Ocache}', r'\textsc{RandomPart}']

    i = 1 # Heuristique
    
    filename, file_extension = os.path.splitext(all_csv[i])
    filename = os.path.basename(filename)
    #print (all_data[i])

    if args.dom:
        plot([all_data[0], all_data[1], all_data[2], all_data[3], all_data[4], all_data[5]], '../'+'proc-'+filename+'dom.pdf', args.step, args.xaxis, [labels[0], labels[1], labels[2], labels[3], labels[4], labels[5]], proc=True)
        print ('../'+'proc-'+filename+'dom.pdf')
        plot([all_data[0], all_data[1], all_data[2], all_data[3], all_data[4], all_data[5]], '../'+'cache-'+filename+'dom.pdf', args.step, args.xaxis, [labels[0], labels[1], labels[2], labels[3], labels[4], labels[5]], proc=False)
        print ('../'+'cache-'+filename+'dom.pdf')
    elif args.minratio:
        plot([all_data[1], all_data[6],  all_data[7],  all_data[8]], '../'+'proc-'+filename+'minratio.pdf', args.step, args.xaxis, [labels[1], labels[6], labels[7], labels[8]], proc=True)
        print ('../'+'proc-'+filename+'minratio.pdf')
        plot([all_data[1], all_data[6],  all_data[8]], '../'+'cache-'+filename+'minratio.pdf', args.step, args.xaxis, [labels[1], labels[6], labels[8]], proc=False)
        print ('../'+'cache-'+filename+'minratio.pdf')
    else:
        plot([all_data[1], all_data[6], all_data[7]], '../'+'proc-'+filename+'.pdf', args.step, args.xaxis, [labels[1], labels[6], labels[7]], proc=True)
        print ('../'+'proc-'+filename+'.pdf')
        plot([all_data[1], all_data[6]], '../'+'cache-'+filename+'.pdf', args.step, args.xaxis, [labels[1], labels[6]], proc=False)
        print ('../'+'cache-'+filename+'.pdf')
  
