#!/usr/local/bin/python3
#Author: Loïc Pottier


import sim
import plot

import argparse
import math
import sys
import statistics
import random
import csv
import itertools
from timeit import default_timer as timer


# [w_, f_ m40MBS_s]
npbs = {'CG': [5.70E+10,7.62E-01,6.59E-04], 'BT': [2.10E+11, 8.29E-01, 7.31E-03], 'LU': [1.52E+11, 7.50E-01, 1.51E-03], 'SP': [1.38E+11, 7.62E-01, 1.51E-02], 'MG': [1.23E+10, 5.40E-01, 2.62E-02], 'FT': [1.65E+10, 5.82E-01, 1.78E-02] }

def init_random(n, inf, sup, integer=False):
    if integer:
        return [random.randint(inf,sup) for i in range(n)]
    else:
        return [random.uniform(inf, sup) for i in range(n)]


### Initialisation functions

# Manu's Value : CG BT LU SP MG FT : six tasks
def init_npbs(s=[]):
    w = [npbs[x][0] for x in npbs]
    f = [npbs[x][1] for x in npbs]
    m40MBSs = [npbs[x][2] for x in npbs]
    s = [random.uniform(0.01, 0.15) for i in range(6)] # fraction seq entre 1 et 15%
    #print (w,f,m40MBSs,s)
    return (w,f,m40MBSs,s)

#synthetique npbs
def init_synthe_npbs(n, s=[]):
    npbs_rnd = [random.choice(list(npbs.keys())) for i in range(n)]
    w = init_random(n, 1E+8, 1E+12)
    f = [npbs[x][1] for x in npbs_rnd]
    m40MBSs = [npbs[x][2] for x in npbs_rnd]
    #print ("NPBS set {} and w={} f={} and m40MB={}".format(npbs_rnd, w, f, m40MBSs)
    
    s = [random.uniform(0.01, 0.15) for i in range(n)] # fraction seq entre 1 et 15%
    #print (s)
    return (w,f,m40MBSs,s)

#Amdhal synthetique
def init_random_40MB(n, s=[]):
    w = init_random(n, 1E+8, 1E+12)
    f = init_random(n, 1E-01, 9E-01)
    m40MBSs = init_random(n, 1E-02, 9E-04)
    s = [random.uniform(0.01, 0.15) for i in range(n)] # fraction seq entre 1 et 15%
    return (w,f,m40MBSs,s)

######### TMPPPPPPP

#def init_random_40MB(n):
#    w = init_random(n, 1E+10, 2E+11)
#    f = init_random(n, 0.1, 0.9)
#    m40MBSs = init_random(n, 0.1, 0.9)
#    s = [random.uniform(0.01, 0.15) for i in range(n)] # fraction seq entre 1 et 15%
#    return (w,f,m40MBSs,s)

### Others

def init_random_m40MBS(n, val_m40MBSs,s=[]):
    w = init_random(n, 1E+8, 1E+12)
    f = init_random(n, 1E-01, 9E-01)
    m40MBSs = [val_m40MBSs]*n
    s = [random.uniform(0.01, 0.15) for i in range(n)] # fraction seq entre 1 et 15%
    return (w,f,m40MBSs,s)

def init_npbs_m40MBS(n, val_m40MBSs, s=[]):
    npbs_rnd = [random.choice(list(npbs.keys())) for i in range(n)]
    #tmp = itertools.cycle(list(npbs.keys()))
    #npbs_rnd = [next(tmp) for i in range(n)]
    #w = [npbs[x][0] for x in npbs_rnd]
    w = init_random(n, 1E+8, 1E+12)
    f = [npbs[x][1] for x in npbs_rnd]
    m40MBSs = [val_m40MBSs]*n
    #print ("NPBS set {} and w={} f={} and m40MB={}".format(npbs_rnd, w, f, m40MBSs)
    
    s = [random.uniform(0.01, 0.15) for i in range(n)] # fraction seq entre 1 et 15%
    return (w,f,m40MBSs,s)

#def init_all_npbs_m1MBS(n, inf, sup, val_m1MBSs):
#    npbs_rnd = [random.choice(list(npbs.keys())) for i in range(n)]
    #tmp = itertools.cycle(list(npbs.keys()))
    #npbs_rnd = [next(tmp) for i in range(n)]
#    w = [npbs[x][0] for x in npbs_rnd]
#    f = [npbs[x][1] for x in npbs_rnd]
    
#    m1MBSs = [val_m1MBSs]*n
#    return (w,f,m1MBSs)

# *arg -> arguments pour func_init qui initialise les tableaux 
def run(nbrun, n_, p_, cs_, ls_, cl_, ll_, alpha_, _fs, cache_baseline, func_init, *args):
    data_exp = []
    data_arrays = [func_init(*args) for i in range(nbrun)]
    for i in range(nbrun):
        (w,f,m1MBSs,seq_frac) = data_arrays[i]
        #print ("--------{}--------".format(i))
        #print (seq_frac)
        res = sim.simulation(n_, p_, cs_, ls_, cl_, ll_, alpha_, w, f, m1MBSs, seq_frac, cache_baseline)
        
        data_exp.append(res)
        #print("{}/{} {}".format(i, nbrun-1, data_exp[i]))    
    return data_exp

def write_csv(data, out_file, info):
    with open(out_file, 'w', newline='') as f:
        writer = csv.writer(f, delimiter=' ')
        writer.writerow(info) # useful information to understand data (order, etc)
        for exp in data:
            writer.writerow(exp)


def write_multiple_csv(data, out_file, info):
    name_file = ['AllProcCache', 'DominantRandom', 'DominantMinRatio', 'DominantMaxRatio', 'DominantMinWifidi', 'DominantRevRandom', 'DominantRevMinRatio',  'DominantRevMaxRatio', 'DominantRevMinWifidi', 'RandomPart', 'Equals', 'Fair', 'Ocache']
    i = 6  #first p_i
    j = 19 #first x_i
    print (data)

    for f in name_file:
        with open(f+'-'+out_file, 'w', newline='') as f:
            writer = csv.writer(f, delimiter=' ')
            writer.writerow(info) # useful information to understand data (order, etc)
            for exp in data:
                new_data = exp[:6]+exp[i]+exp[j]
                writer.writerow(new_data)
            i = i + 1
            j = j + 1

def read_csv(in_file):
    with open(in_file, newline='') as csvfile:
        reader = csv.reader(csvfile, delimiter=' ')
        return row

def create_tab_moy(data_pi):
    data_col_pi = [ [x[j] for x in data_pi] for j in range(len(data_pi[0])) ]
    #print (data_col_pi)

    res = []
    
    for i in range(len(data_col_pi[0][0])):
        temp = [statistics.mean([e[i] for e in data_col_pi[j]]) for j in range(len(data_col_pi)) ]
        #print (temp)
        res.append(temp)
    return res

def main(args):
    # tab_n = [n+16*i for i in range(nbexp)]
    # tab_n = list(map(lambda x: x-1, tab_n))
    # tab_n[0] = 1

    average = []
    
    cl = args.cs * 1000
    
    #args.nbexp = int((args.p-args.n)/args.n)+1
    #tab_n = [args.n+6*i for i in range(int((args.p-args.n)/args.n)+1)] # Xeon Phi KNL 288

    tab_n = [1]+[args.n+4*i for i in range(1,args.nbexp+1)] # classic
    #tab_n = [args.n for i in range(args.nbexp)]

    #tab_p = [1]+[args.p+4*i for i in range(1,args.nbexp+1)]
    tab_p = [args.p for i in range(args.nbexp)]

    # 2D TAB !
    #tmp_fs=[0.00001]*args.n
    #tab_fs = [tmp_fs] + [[0.01*i for j in range(args.n)] for i in range(1,args.nbexp+1)]
    #tab_fs = [[0.0001]*args.n for i in range(1,args.nbexp+1)]
    #tab_fs = [[0.18 for j in range(args.n)] for i in range(args.nbexp+1)]
    #tab_fs = [[random.uniform(0.01, 0.15) for i in range(args.n)] for k in range(args.nbexp)] # fraction seq entre 1 et 15%
    tab_fs = [[random.uniform(0.01, 0.15) for i in range(tab_n[k])] for k in range(args.nbexp)] # fraction seq entre 1 et 15%
    #print ("tab_fs={}".format(tab_fs))

    if args.varymiss:
        tab_40MBSs = [float(1.0/args.nbexp)*(1+i) for i in range(args.nbexp)]
    if args.varyls:
        tab_ls = [float(1.0/args.nbexp)*(1+i) for i in range(args.nbexp)]
    
    ##### BEGIN
    ##### WARNING même les random init sont en 40MB !
    ##### END

    data_final_pi = []
    data_final_xi = []

    #print (args.nbexp)
    
    for k in range(args.nbexp):
        #Amdahl's synthétique
        if args.random:
            data = run(args.nbrun, tab_n[k], tab_p[k], args.cs, args.ls, cl, 1, args.alpha, tab_fs[k], 40, init_random_40MB, tab_n[k], tab_fs[k])
        #Manu's data
        elif args.npbs:
            data = run(args.nbrun, tab_n[k], tab_p[k], args.cs, args.ls, cl, 1, args.alpha, tab_fs[k], 40, init_npbs, tab_fs[k])
        #Synthétique manu
        elif args.npbs_multi:
            data = run(args.nbrun, tab_n[k], tab_p[k], args.cs, args.ls, cl, 1, args.alpha, tab_fs[k], 40, init_synthe_npbs, tab_n[k], tab_fs[k])
        elif args.varymiss:
            data = run(args.nbrun, tab_n[k], tab_p[k], args.cs, args.ls, cl, 1, args.alpha, tab_fs[k], 40, init_npbs_m40MBS, tab_n[k], tab_40MBSs[k], tab_fs[k])        
        elif args.varyls:
            data = run(args.nbrun, tab_n[k], tab_p[k], args.cs, tab_ls[k], cl, 1, args.alpha, tab_fs[k], 40, init_synthe_npbs, tab_n[k], tab_fs[k])        

        #print (data)
        #print ("------")
        data_mksp = [e[0] for e in data]
        data_pi = [e[1] for e in data]
        data_xi = [e[2] for e in data]
        data_col = [ [x[j] for x in data_mksp] for j in range(len(data_mksp[0])) ]

        #Moyenne les tab_min_pi, tab_max_pi etc, on ecrit dans un fichier par heurisitique
        #data_final_xi.append(create_tab_moy(data_xi))
        #print (data_final_pi)
        #print ("------")
        #print (data_final_xi)
        data_final_pi.append([tab_n[k], tab_p[k], args.cs, args.ls, args.alpha, statistics.mean(tab_fs[k])] + create_tab_moy(data_pi) + create_tab_moy(data_xi))
        #print ("data_final_pi add {}".format(data_final_pi))
        
        if args.varymiss:
            print ("WARNING VARYMISS")
            #print (data_col)
            average.append([tab_n[k], tab_p[k], args.cs, args.ls, tab_40MBSs[k], statistics.mean(tab_fs[k])] + [statistics.mean(heur) for heur in data_col])
            print("{:>3}/{:>3} : n={:>4} p={:>4} (fs={} and m1MBSs={}) -> average on {:>3} runs : {}".format(k, args.nbexp-1, tab_n[k], tab_p[k], statistics.mean(tab_fs[k]), tab_40MBSs[k], args.nbrun, ["%0.3f" % x for x in average[k][6:]]))
        elif args.varyls:
            print ("WARNING VARYLS")
            #print (data_col)
            average.append([tab_n[k], tab_p[k], args.cs, tab_ls[k], args.alpha, statistics.mean(tab_fs[k])] + [statistics.mean(heur) for heur in data_col])
            print("{:>3}/{:>3} : n={:>4} p={:>4} (fs={} and ls={}) -> average on {:>3} runs : {}".format(k, args.nbexp-1, tab_n[k], tab_p[k], statistics.mean(tab_fs[k]), tab_ls[k], args.nbrun, ["%0.3f" % x for x in average[k][6:]]))
        else:
            average.append([tab_n[k], tab_p[k], args.cs, args.ls, args.alpha, statistics.mean(tab_fs[k])] + [statistics.mean(heur) for heur in data_col])
            print("{:>3}/{:>3} : n={:>4} p={:>4} (fs={}) -> average on {:>3} runs : {}".format(k, args.nbexp-1, tab_n[k], tab_p[k], statistics.mean(tab_fs[k]), args.nbrun, ["%0.3f" % x for x in average[k][6:]]))


    return (average, data_final_pi)

if __name__ == "__main__":
    res = []

    parser = argparse.ArgumentParser()
    parser.add_argument('-nbrun', type=int, default=50, help="Number of runs")
    parser.add_argument('-nbexp', type=int, default=1, help="Number of experiments (varying values)")

    parser.add_argument('-n', type=int, default=4, help="Number of tasks")
    parser.add_argument('-p', type=int, default=8, help="Number of processors")
    parser.add_argument('-cs', type=int, default=8, help="Cache size (MiB)")
    parser.add_argument('-ls', type=float, default=0.16, help="Cache latency (DDR latency = 1)")
    parser.add_argument('-alpha', type=float, default=0.5, help="Parameter for Power Law")
    parser.add_argument('-fs', help="Sequential fraction of work", action="store_true")

    parser.add_argument('-npbs', help="Manu's values (six tasks)", action="store_true")    
    parser.add_argument('-npbs_multi', help="Generate synthetic tasks with manu's value for f and m40MBSs", action="store_true")

    parser.add_argument('-varymiss', help="WARNING: Vary m1MBSs with Manu's value (npbs_synth)", action="store_true")
    parser.add_argument('-varyls', help="WARNING: Vary ls from 0 to 1 with Manu's value (npbs_synth)", action="store_true")
    
    parser.add_argument('-random', help="Generate random values for w, f and m40MBSs according to Manu's data", action="store_true")    
#    parser.add_argument('-inf', type=int, default=1, help="Inf value for random task generations")
#    parser.add_argument('-sup', type=int, default=10, help="Inf value for random task generations")

    if len(sys.argv[1:]) == 0:
        parser.print_help()
        parser.exit()

    args = parser.parse_args()
    args.cs = args.cs * math.pow(10,6)

    if args.random and args.npbs:
        print("Error: -npbs and -random are used at the same time")
        parser.print_help()
        parser.exit()
        
    #if args.random and (args.inf == None or args.sup == None):
    #    print("Error: -inf or -sup without value")
    #    parser.print_help()
    #    parser.exit()
        
    if args.npbs and (args.n != len(npbs)):
        print("Error: n not equal to size of npbs data")
        parser.print_help()
        parser.exit()

#    if args.npbs:
#        args.n = len(npbs)
#        print("Warning: You use  npbs data, so n = {}".format(args.n))

    
    try:
        start = timer()
        res = main(args)
        end = timer()
        print ("Time elaspsed {} s".format(end - start))
    except KeyboardInterrupt:
        print("\n")
        print("Exception handled, data wrote.")
    finally:
        data_col = [ [x[j] for x in res[0]] for j in range(len(res[0][0]))]
        n = data_col[0]
        p = data_col[1]
        Cs = data_col[2]
        ls = data_col[3]
        alpha = data_col[4]

        if args.npbs:
            out_csv = 'npbs-n-{}to{}_p-{}to{}-Cs-{}_ls-{}_alpha-{}'.format(min(n),max(n),min(p),max(p), args.cs, args.ls, args.alpha)
        if args.npbs_multi:
            out_csv = 'multinpbs-n-{}to{}_p-{}to{}-Cs-{}_ls-{}_alpha-{}'.format(min(n),max(n),min(p),max(p), args.cs, args.ls, args.alpha)
        elif args.random:
            out_csv = 'random-n-{}to{}_p-{}to{}-Cs-{}_ls-{}_alpha-{}'.format(min(n),max(n),min(p),max(p), args.cs, args.ls, args.alpha)
        elif args.varymiss:
            out_csv = 'varymiss-n-{}to{}_p-{}to{}-Cs-{}_ls-{}_alpha-{}'.format(min(n),max(n),min(p),max(p), args.cs, args.ls, args.alpha)
        elif args.varyls:
            out_csv = 'varyls-n-{}to{}_p-{}to{}-Cs-{}_ls-{}_alpha-{}'.format(min(n),max(n),min(p),max(p), args.cs, args.ls, args.alpha)

        if args.fs:
            out_csv += '_fs-0.0'

        out_csv += '.csv'

        out_csv1 = 'output/'+out_csv
        out_csv2 = 'output-repart/'+out_csv
            
        labels = ['N', 'P', 'Cs', 'ls', 'alpha', 'fs', 'AllProcCache', 'DominantRandom', 'DominantMinRatio', 'DominantMaxRatio', 'DominantMinWifidi', 'DominantRevRandom', 'DominantRevMinRatio',  'DominantRevMaxRatio', 'DominantRevMinWifidi', 'RandomPart', 'Equals', 'Fair', 'Ocache']

        write_csv(res[0], out_csv1, labels)
        
        write_multiple_csv(res[1], out_csv, ['N', 'P', 'Cs', 'ls', 'alpha', 'fs', 'p_min', 'p_max', 'p_avg', 'x_min', 'x_max', 'x_avg'])

        print (out_csv)
        
        
