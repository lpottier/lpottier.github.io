#!/usr/bin/env python3

import io
import os
import sys
import time
import functools
import contextlib
import random

#logfile = sys.stderr
logfile = open(os.devnull, 'w')

class colors:
    header = '\033[95m'
    okblue = '\033[94m'
    okgreen = '\033[92m'
    warning = '\033[93m'
    fail = '\033[91m'
    endc = '\033[0m'
    bold = '\033[1m'
    underline = '\033[4m'

def print_ok(module, msg, stdout=logfile):
	print("[      "+ colors.okgreen+colors.bold +"OK" + colors.endc + "     ] %s(%s): %s " %(module, time.strftime("%d/%m/%Y-%H:%M:%S[%Z]"), msg), file=stdout)

def print_warning(module, msg, stdout=logfile):
	print("[   "+ colors.warning+colors.bold +"WARNING" + colors.endc + "   ] %s(%s): %s " %(module, time.strftime("%d/%m/%Y-%H:%M:%S[%Z]"), msg), file=stdout)

def print_error(module, msg, stdout=logfile):
	print("[    "+ colors.fail+colors.bold +"ERROR" + colors.endc + "    ] %s(%s): %s " %(module, time.strftime("%d/%m/%Y-%H:%M:%S[%Z]"), msg), file=stdout)

def timing(f):
	@functools.wraps(f)
	def wrap(*args, **kw):
		ts = time.time()
		result = f(*args, **kw)
		te = time.time()		
		print('[{} {:^14s} {}] {:6.4f} sec'.format(colors.okblue, f.__name__, colors.endc, te-ts))
		return result
	return wrap

@contextlib.contextmanager
def nostdout():
	save_stdout = sys.stdout
	sys.stdout = io.BytesIO()
	yield
	sys.stdout = save_stdout

def argmax(iterable):
    return max(enumerate(iterable), key=lambda x: x[1])

def argmin(iterable):
    return min(enumerate(iterable), key=lambda x: x[1])
