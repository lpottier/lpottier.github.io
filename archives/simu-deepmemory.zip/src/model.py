#!/usr/bin/env python3

import sys
import networkx as nx
import dag

"""
Model functions
"""

def sigma_1(G, v_i):
	return G.node[v_i]['sigma_1']

def sigma_2(G, v_i):
	return G.node[v_i]['sigma_2']

def total_in(G, v_i):
	in_i = 0
	for v_j in G.predecessors(v_i):
		in_i = in_i + G.adj[v_j][v_i]['weight']
	return in_i

def total_out(G, v_i):
	out_i = 0
	for v_j in G.successors(v_i):
		out_i = out_i + G.adj[v_i][v_j]['weight']
	return out_i

def in_s(G, v_i):
	ins_i = 0
	for v_j in G.predecessors(v_i):
		ins_i = ins_i + (G.adj[v_j][v_i]['weight'] - G.adj[v_j][v_i]['ef'])*G.adj[v_j][v_i]['n']
	return ins_i

def out_s(G, v_i):
	outs_i = 0
	for v_j in G.successors(v_i):
		outs_i = outs_i + (G.adj[v_i][v_j]['weight'] - G.adj[v_i][v_j]['ef'])
	return outs_i

def in_f(G, v_i):
	inf_i = 0
	for v_j in G.predecessors(v_i):
		inf_i = inf_i + G.adj[v_j][v_i]['ef']*G.adj[v_j][v_i]['n']
	return inf_i

def out_f(G, v_i):
	outf_i = 0
	for v_j in G.successors(v_i):
		outf_i = outf_i + G.adj[v_i][v_j]['ef']
	return outf_i

def running_tasks(G, k):
	return [v_i for v_i in G.nodes() if sigma_1(G, v_i) <= k < sigma_2(G, v_i)]

def tasks_accessing_slow_mem(G, k):
	res = set()
	for v_i in running_tasks(G, k):
		for v_j in G.predecessors(v_i):
			if G.adj[v_j][v_i]['ef'] == 0:
				res = res.union([v_i])
		for v_j in G.successors(v_i):
			if G.adj[v_i][v_j]['ef'] == 0:
				res = res.union([v_i])
	return list(res)

def tasks_accessing_fast_mem(G, k):
	res = set()
	for v_i in running_tasks(G, k):
		for v_j in G.predecessors(v_i):
			if G.adj[v_j][v_i]['ef'] > 0:
				res = res.union([v_i])
		for v_j in G.successors(v_i):
			if G.adj[v_i][v_j]['ef'] > 0:
				res = res.union([v_i])
	return list(res)

"""
Compute w_i^(k)
"""

def compute_bottleneck(G, v_i, s, k, Bf, Bs):
	w_i = G.node[v_i]['workload']

	# print("-------------")
	# print("v_i=", v_i)
	# print("in_f",in_f(G, v_i))
	# print("in_s",in_s(G, v_i))
	# print("out_f",out_f(G, v_i))
	# print("out_s",out_s(G, v_i))
	# print("-------------")

	if in_f(G, v_i)+out_f(G, v_i) > 0 and in_s(G, v_i)+out_s(G, v_i) <= 0:
		#If all blocks in fast memory
		Xf = (Bf[k]*w_i)/(in_f(G, v_i)+out_f(G, v_i))
		#print ("v_i=",v_i,"s=",s,"Xf=", Xf, "------> return ", min(s, Xf))
		return min(s, Xf)

	elif in_f(G, v_i)+out_f(G, v_i) > 0 and in_s(G, v_i)+out_s(G, v_i) > 0:
		#If blocks in both memory
		Xf = (Bf[k]*w_i)/(in_f(G, v_i)+out_f(G, v_i))
		Xs = (Bs[k]*w_i)/(in_s(G, v_i)+out_s(G, v_i))
		#print ("v_i=",v_i,"s=",s,"Xf=", Xf, "Xs=",Xs, "------> return ", min(s, Xf, Xs))
		return min(s, Xf, Xs)

	elif in_f(G, v_i)+out_f(G, v_i) <= 0 and in_s(G, v_i)+out_s(G, v_i) > 0:
		#If all blocks in slow memory
		Xs = (Bs[k]*w_i)/(in_s(G, v_i)+out_s(G, v_i))
		#print ("Bs=",Bs[k], "   v_i=",v_i,"s=",s, "Xs=",Xs,"------> return ", min(s, Xs))
		return min(s, Xs)

	elif in_f(G, v_i)+out_f(G, v_i) == 0 and in_s(G, v_i)+out_s(G, v_i) == 0:
		#e_ij == 0, can happen for dummy edges
		#print ("v_i=",v_i,"s=",s, "------> return ", s)
		return s # No communication

	else:
		raise ValueError("Negative number of data blocks")

def w(G, v_i, s, k, t, Bf, Bs):
	#assert(t[k+1] >= t[k]), "v_%s (w = %f) -> t[%d]=%d is not > t[%d]=%d" % (v_i, G.node[v_i]['workload'], k+1, t[k+1], k, t[k])
	#if t[k+1] < t[k]:
		#print("v_%s (w = %f) -> t[%d]=%d is not > t[%d]=%d" % (v_i, G.node[v_i]['workload'], k+1, t[k+1], k, t[k]))
	X = compute_bottleneck(G, v_i, s, k, Bf, Bs)
	return (t[k+1] - t[k])*X

"""
Compute E_i^(k)
"""
def exe(G, v_i, s, k, t, Bf, Bs):
	w_i = G.node[v_i]['workload']

	if (w_i == 0):
		#print("v_i=", v_i, " Exe=", max((in_f(G, v_i)+out_f(G, v_i))/Bf[k] , (in_s(G, v_i)+out_s(G, v_i))/Bs[k]), " with e_f= ",in_f(G, v_i)+out_f(G, v_i), " e_s=",in_s(G, v_i)+out_s(G, v_i), "Bf[k]=", Bf[k], "Bs[k]=", Bs[k] )
		return max((in_f(G, v_i)+out_f(G, v_i))/Bf[k] , (in_s(G, v_i)+out_s(G, v_i))/Bs[k])

	X = compute_bottleneck(G, v_i, s, k, Bf, Bs)
	sum_w = 0
	for kprime in range(sigma_1(G, v_i), k):
		#print(v_i, kprime, w(G, v_i, s, kprime, t, Bf, Bs))
		sum_w = sum_w + w(G, v_i, s, kprime, t, Bf, Bs)

	#print(v_i, w_i, sum_w, X, Bf[k], Bs[k],tasks_accessing_slow_mem(G,k))
	#assert(w_i >= sum_w+sys.float_info.epsilon ), "w_%s=%f must be >= sum_w=%f" % (v_i, w_i, sum_w)
	#print("v_i=", v_i, " Exe=", (w_i - sum_w)/X, " with in_f= ",in_f(G, v_i), " out_f=",out_f(G, v_i))
	#if not (w_i - sum_w)/X > 0:
	 	#print("t[{}]={} and E={} (w_{} = {})".format(k, t[k], (w_i - sum_w)/X, v_i, w_i))
	 	#raise KeyboardInterrupt()
	return t[k] + (w_i - sum_w)/X

def next_finishing_task(G, s, k, t, Bf, Bs):
	min_exe = sys.maxsize
	min_i = '-1'
	for v_i in running_tasks(G, k):
		if min_exe > exe(G, v_i, s, k, t, Bf, Bs):
			min_exe = exe(G, v_i, s, k, t, Bf, Bs)
			min_i = v_i
	assert(int(min_i) >= 0), "min_i=%s and min_exe=%f" % (min_i, min_exe)
	return (min_i, min_exe)

def ready_tasks(G, k):
	#unstarted_tasks = [v_i for v_i in G.nodes() if sigma_1(G, v_i) > k]
	#run_tasks = [v_i for v_i in G.nodes() if sigma_1(G, v_i) <= k < sigma_2(G, v_i)]
	ready_tasks = set()
	for v_i in G.nodes():
		acc = 0
		for v_j in G.predecessors(v_i):
			if sigma_1(G, v_i) > k+1 and sigma_2(G, v_j) <= k+1:
				acc = acc + 1
		if len(list(G.predecessors(v_i))) > 0 and len(list(G.predecessors(v_i))) == acc:
			ready_tasks = ready_tasks.union([v_i])

	return list(ready_tasks)



