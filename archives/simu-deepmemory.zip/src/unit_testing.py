#!/usr/bin/env python3

import tempfile
import sys
import errno
import os
import shutil
import networkx as nx
import utils

import dag

def init_test():
	tmp_dir = tempfile.mkdtemp()
	print("[   "+ utils.colors.okgreen +"OK" + utils.colors.endc + "  ] unit_testing: created temporary directory", tmp_dir, file=sys.stderr)
	return tmp_dir

def close_test(tmp_dir):
	try:
	    shutil.rmtree(tmp_dir)
	    print("[   "+ utils.colors.okgreen +"OK" + utils.colors.endc + "  ] unit_testing: destroyed temporary directory", tmp_dir, file=sys.stderr)
	except OSError as e:
	    print("[  "+ utils.colors.fail +"FAIL" + utils.colors.endc + " ] unit_testing:", os.strerror(e.errno), file=sys.stderr)


def init_graph(tmp_dir, num_test, size_fast_mem, nb_proc, out):
	f=tmp_dir+'/test_'+str(num_test)+'.dag'

	dag.generate(f, ["ggen", "static-graph", "forkjoin", "1", "5"], out)
	G = dag.create(f, 'test_'+str(num_test), size_fast_mem, nb_proc)
	dag.initialize(G, 1, 1, 1)

	assert nx.is_directed_acyclic_graph(G)

	print("[   "+ utils.colors.okgreen +"OK" + utils.colors.endc + "  ] unit_testing: initialize direct acyclic graph G =", G, file=sys.stderr)

	return G

def dag_attr(G):
	#TODO: check len(G.nodes) == 1+5
	#TODO: sum the attr weight on edges and verify that sum == len(G.edges)
	u = '0'
	v = '1'
	ef_uv = 42
	d_edges = {(u,v):ef_uv}
	attr_edge = 'ef'

	dag.update_edges(G, attr_edge, d_edges)
	assert G[u][v][attr_edge] == ef_uv
	print("[   "+ utils.colors.okgreen +"OK" + utils.colors.endc + "  ] unit_testing: testing dag.update_edges", file=sys.stderr)

	u = '0'
	w_uv = 11
	d_nodes = {u:w_uv}
	attr_node = 'workload'

	dag.update_nodes(G, attr_node, d_nodes)
	assert G.node[u][attr_node] == w_uv
	print("[   "+ utils.colors.okgreen +"OK" + utils.colors.endc + "  ] unit_testing: testing dag.update_nodes", file=sys.stderr)


def dag_roots(G):
	r = dag.roots(G)
	dag.add_dummy_root(G)
	assert len(dag.roots(G)) == 1
	print("[   "+ utils.colors.okgreen +"OK" + utils.colors.endc + "  ] unit_testing: testing dag.add_dummy_root", file=sys.stderr)


def dag_subgraph(G):
	try:
		if len(dag.roots(G)) > 1:
			dag.add_dummy_root(G)
		assert len(dag.roots(G)) == 1
		r = dag.roots(G)
		G_r = dag.rooted_subgraph(G, r[0])

		for i in G.nodes():
			assert i in G_r.nodes()
		for e in G.edges():
			assert e in G_r.edges()
			
		print("[   "+ utils.colors.okgreen +"OK" + utils.colors.endc + "  ] unit_testing: testing dag.rooted_subgraph", file=sys.stderr)
	except AssertionError as e:
		print("[  "+ utils.colors.fail +"FAIL" + utils.colors.endc + " ] unit_testing: testing dag.rooted_subgraph", file=sys.stderr)


def model_critical_path():
	#TODO verifier que le temps d'exec est bien egale au critical path
	#model.critical_path(test_0.graph, '0', test_0.speed, test_0.bandwidth_slow)
	pass



