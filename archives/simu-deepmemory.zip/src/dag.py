#!/usr/bin/env python3

import sys
import os
import subprocess
import networkx as nx
import utils

#Use ggen to generate a dot file containing the DAG
def generate(file_out, arg_ggen, output=True):
	if output:
		out=2
	else:
		out=subprocess.DEVNULL
	try:
		retcode = subprocess.call(arg_ggen + ["-o", str(file_out)], stdout=out, stderr=subprocess.STDOUT)
		if retcode < 0:
			utils.print_warning("dag", "child was terminated by signal:"+str(retcode))
	except OSError as e:
		utils.print_error("dag", "execution failed:"+os.strerror(e.errno))


def create(file_in, dag_name, size_mem, p):
    G = nx.DiGraph(nx.nx_agraph.read_dot(file_in), name=dag_name, fast_mem=size_mem, proc=p) #NetworkX DiGraph
    G = nx.relabel_nodes(G, lambda u: str(int(u)+1)) #Node from 1 to max (instead of 0 to max-1), then th dummy root will be '0'
    return G

# G: DiGraph
# nodes_dict: dict[i]={w_i}
# edges_dict: dict[(i,j)]={e_ij} 
def initialize(G, nodes_workload, edges_weight, edges_nij):
	nx.set_node_attributes(G, name='workload', values=nodes_workload) 	#set w_i (workload)
	nx.set_node_attributes(G, name='sigma_1', values=sys.maxsize) 		#set sigma_1(i) to +oo
	nx.set_node_attributes(G, name='sigma_2', values=sys.maxsize) 		#set sigma_2(i) to +oo

	nx.set_edge_attributes(G, name='weight', values=edges_weight) 		#set e_ij (data blocks)
	nx.set_edge_attributes(G, name='n', values=edges_nij) 				#set n_ij (the number of read blocks)
	nx.set_edge_attributes(G, name='ef', values=0) 						#set e^f_ij (data blocks from fast memory)
	# nx.set_edge_attributes(G, 'gamma', 0) 					#set gamma_ij (transfer prior execution)
	# nx.set_edge_attributes(G, 'alpha', 0) 					#set alpha_ij (transfer prior execution)


# G: DiGraph
# attr: string 
# edges_dict: dict[(i,j)]={e_ij}
def update_edges(G, attr, edges_dict):
	_attr = str(attr)
	try:
		for (u,v) in edges_dict.keys():
			_u = str(u)
			_v = str(v)
			G.edge[_u][_v][_attr] = edges_dict[(u,v)]
	except KeyError as e:
		utils.print_error("dag.update_edges", _attr+"or edge ("+_u+","+_v+") does not exist")

def update_nodes(G, attr, nodes_dict):
	_attr = str(attr)
	try:
		for u in nodes_dict.keys():
			_u = str(u)
			G.node[_u][_attr] = nodes_dict[u]
	except KeyError as e:
		utils.print_error("dag.update_nodes", "attr ="+_attr+"or node"+_u+" does not exist")

def roots(G):
	# topo_sort = nx.topological_sort(G)
	# roots = [u for u in topo_sort if len(G.predecessors(u)) == 0]
	#return [n for n,d in G.in_degree().items() if d==0]
	return [x for x in G.nodes() if G.in_degree(x)==0]

def root(G):
	root = [x for x in G.nodes() if G.in_degree(x)==0]
	if len(root) != 1:
		raise NetworkXError("more than one roots")
	return root[0]


def add_dummy_root(G):
	l_roots = roots(G)
	id_dummy_root = '0'
	G.add_node(id_dummy_root)
	G.node[id_dummy_root]['workload'] = 0
	for r in l_roots:
		G.add_edge(id_dummy_root, r)


def rooted_subgraph(G, root):
	# def node_subset(G, x):
	# 	V_x = set(x)
	# 	for i in G.successors(x):
	# 		if len(G.successors(i))==0:
	# 			V_x = V_x | {i}
	# 		else:
	# 			V_x = V_x | node_subset(G,i)
	# 	return V_x
	nodes = nx.dfs_preorder_nodes(G, root)
	return nx.DiGraph(nx.subgraph(G,nodes))



