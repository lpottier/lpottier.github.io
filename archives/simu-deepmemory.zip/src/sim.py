#!/usr/bin/env python3

import sys
import shutil
import tempfile
import random
import math

import networkx as nx

import dag
import model
import utils

class Simulation:
	def __init__(self, name, ggen, graph, proc, speed, size_fast, bandwidth_fast, bandwidth_slow, seed, dotfile=False):
		if graph == None and ggen == None:
			raise ValueError("no graph provided.")

		self.name = name
		self.ggen = ggen
		self.proc = proc
		self.speed = speed
		self.size_fast = size_fast
		self.bandwidth_fast = bandwidth_fast
		self.bandwidth_slow = bandwidth_slow
		self.sim_dir = tempfile.mkdtemp()
		self.seed = seed

		if not dotfile:
			file_dir = self.sim_dir+'/'+self.name+'.dag'
			utils.print_ok("sim", "created temporary directory "+self.sim_dir)
			if graph==None and ggen != None:
				dag.generate(file_dir, self.ggen, output=False)
				self.graph = dag.create(file_dir, self.name, self.size_fast, self.proc)
			elif graph != None and ggen == None:
				self.graph = graph
				self.graph = nx.relabel_nodes(self.graph, lambda u: str(int(u)+1)) #Node from 1 to max (instead of 0 to max-1), then th dummy root will be '0'
			if len(dag.roots(self.graph)) > 1:
				dag.add_dummy_root(self.graph)
		else:
			self.graph = graph
			#self.graph = nx.relabel_nodes(self.graph, lambda u: str(int(u)-1)) 

	def __enter__(self):
		return self

	def __exit__(self, exc_type, exc_value, traceback): 
		try:
		    shutil.rmtree(self.sim_dir)
		    utils.print_ok("sim", "destroyed temporary directory "+self.sim_dir)
		except OSError as e:
		    utils.print_error("sim", "destroyed temporary directory "+os.strerror(e.errno))

	def __repr__(self):
		return "Simulation(name={}, ggen={}, nodes={}, proc={}, speed={}, size_fast={}, bandwidth_fast={}, bandwidth_slow={}, seed={})".format(self.name, str(self.ggen), self.proc, self.speed, self.size_fast, self.bandwidth_fast, self.bandwidth_slow, self.seed)
	def __str__(self):
		s = " name\t\t = {}\n ggen cmd\t = {}\n nodes\t\t = {}\n proc\t\t = {}\n processor speed = {}\n size_fast\t = {}\n bandwidth_fast\t = {}\n bandwidth_slow\t = {}\n seed\t\t = {}".format(self.name, str(self.ggen), self.graph.number_of_nodes(), self.proc, self.speed, self.size_fast, self.bandwidth_fast, self.bandwidth_slow, self.seed)
		return s
		#rank.__name__, iorank.__name__

	def set_seed(self, seed):
		random.seed(seed)

	def initialize_random(self, start_w, stop_w, start_e, stop_e, start_n, stop_n):
		w = {key: random.randint(start_w, stop_w) for key in self.graph.nodes()} # workload (w_i)
		#dag.add_dummy_root(self.graph)
		e = {(key,value): random.randint(start_e, stop_e) for (key,value) in self.graph.edges()}	# e_ij (number of blocks)
		n = {(key,value): random.randint(start_n, stop_n) for (key,value) in self.graph.edges()} 	# n_ij (number of read per block)
		dag.initialize(self.graph, w, e, n)

	#quadratic...
	#@utils.timing
	def compute_cp(self):
		for v_i in self.graph.nodes():
			cp_i = max(self.graph.node[v_i]['workload']/self.speed, (model.total_in(self.graph,v_i)+model.total_out(self.graph,v_i))/self.bandwidth_slow )
			self.graph.node[v_i]['cp_load'] = cp_i

			# As we compute the shortest path
			# we inverse cp_i to to compute the longest path in term of cp_i
			for v_j in self.graph.successors(v_i):
				try:
					self.graph.adj[v_i][v_j]['cp_inv'] = 1.0/cp_i
				except ZeroDivisionError:
					self.graph.adj[v_i][v_j]['cp_inv'] = math.inf

		puit = [x for x in self.graph.nodes() if self.graph.out_degree(x)==0]
		assert(len(puit) == 1)
		puit = puit[0]

		for src in self.graph.nodes():
			self.graph.node[src]['cp'] = 0
			path = nx.dijkstra_path(G = self.graph, source = src, target = puit, weight = 'cp_inv')
			#We compute the sum of all cp_i on the path the largest weight (inversed)
			self.graph.node[src]['cp'] = sum([self.graph.node[v_i]['cp_load'] for v_i in path])
			#print("CP_{} = {} ({}) {} {}".format(src, self.graph.node[src]['cp'], self.graph.node[src]['cp_load'], path, [(v_i,self.graph.node[v_i]['cp_load']) for v_i in self.graph.successors(src)] ) )

			

	"""
	Metrics
	"""
	# def cp(self, v_i):
	# 	cp_i = max(self.graph.node[v_i]['workload']/self.speed, (model.total_in(self.graph,v_i)+model.total_out(self.graph,v_i))/self.bandwidth_slow )
	# 	if len(self.graph.successors(v_i)) > 0:
	# 		return cp_i + max([max(self.graph.node[v_j]['workload']/self.speed, (model.total_in(self.graph,v_j)+model.total_out(self.graph,v_j))/self.bandwidth_slow ) for v_j in self.graph.successors(v_i) ])
	# 	else:
	# 		return cp_i

	def get_cp(self, v_i):
		return self.graph.node[v_i]['cp']
		# cp_i = max(self.graph.node[v_i]['workload']/self.speed, (model.total_in(self.graph,v_i)+model.total_out(self.graph,v_i))/self.bandwidth_slow )
		# #print("--> cp_", v_i, cp_i)
		# if len(self.graph.successors(v_i)) > 0:
		# 	return cp_i + max([ self.cp(v_j) for v_j in self.graph.successors(v_i) ])
		# else:
		# 	return cp_i

	def gain_subgraph(self, v_i):
		time_s = self.bottom_level_slow(v_i, -1)
		time_f = self.bottom_level_fast(v_i, -1)

		try:
			res = float(self.mksp(time_f)) / float(self.mksp(time_s))
		except ZeroDivisionError:
			res = 0

		return res

	def gain_node(self, v_i):
	 	#Gain of using fast memory just for a node, accounting communications
	 	time_s = max(self.graph.node[v_i]['workload']/self.speed, (model.total_in(self.graph,v_i)+model.total_out(self.graph,v_i))/self.bandwidth_slow )
	 	time_f = max(self.graph.node[v_i]['workload']/self.speed, (model.total_in(self.graph,v_i)+model.total_out(self.graph,v_i))/self.bandwidth_fast )

	 	try:
	 		res = float(time_f)/float(time_s)
	 	except ZeroDivisionError:
	 		res = 0
	 	return res


	"""
	Heuristics for scheduling 

	"""

	def CP(self, L):
		L.sort(key=lambda x: self.get_cp(x), reverse=True)

	# def proc_HFT(self, L):
	# 	L.sort(key=lambda x: self.graph.node[x]['workload'], reverse=True)

	def GN(self, L):
		L.sort(key=lambda x: self.gain_node(x), reverse=False)

	def GG(self, L):
		L.sort(key=lambda x: self.gain_subgraph(x), reverse=False)

	# def rank_random(self, L):
	# 	#random.seed(self.seed)
	# 	random.shuffle(L)

	# def rank_sort(self, L):
	# 	L.sort(key=lambda x: int(x))
	
	__proc_heuristics__ = {CP, GG}
	__stencil_proc_heuristics__ = {CP}


	"""

	Heuristics for memory allocation 

	"""

	def mem_CP(self, v_i, Sf, k):
		successors_node = list(self.graph.successors(v_i))
		successors_node.sort(key=lambda x: self.get_cp(x), reverse=True)
		# print([(x,self.get_cp(x)) for x in successors_node])
		for v_j in successors_node:
			assert self.size_fast - Sf[k] >= 0
			eij = self.graph.adj[v_i][v_j]['weight'] # e_ij
			self.graph.adj[v_i][v_j]['ef'] = min(self.size_fast - Sf[k], eij)
			Sf[k] = Sf[k] + self.graph.adj[v_i][v_j]['ef']
		return Sf

	#We sort by w_i and then try to give the same memory amount to each of them
	def mem_EQ(self, v_i, Sf, k):
		successors_node = list(self.graph.successors(v_i))
		successors_node.sort(key=lambda x: self.graph.node[x]['workload'], reverse=True)
		# print([(x,self.graph.node[x]['workload']) for x in successors_node])
		for v_j in successors_node:
			assert self.size_fast - Sf[k] >= 0
			eij = self.graph.adj[v_i][v_j]['weight'] # e_ij
			self.graph.adj[v_i][v_j]['ef'] = min(math.floor((self.size_fast - Sf[k])/len(successors_node)), eij)
			Sf[k] = Sf[k] + self.graph.adj[v_i][v_j]['ef']
		return Sf

	# def mem_Model(self, v_i, Sf, k):
	# 	successors_node = list(self.graph.successors(v_i))
	# 	successors_node.sort(key=lambda x: self.graph.node[x]['workload'], reverse=True)
	# 	for v_j in successors_node:
	# 		assert self.size_fast - Sf[k] >= 0
	# 		eij = self.graph.adj[v_i][v_j]['weight'] # e_ij
	# 		in_j = model.total_in(self.graph, v_j)
	# 		out_j = model.total_out(self.graph, v_j)
	# 		ratio = self.bandwidth_fast/(self.bandwidth_fast+self.bandwidth_slow)
	# 		chosen_value = math.floor((in_j+out_j)*ratio - model.in_f(self.graph, v_j))
	# 		self.graph.adj[v_i][v_j]['ef'] = min(chosen_value, self.size_fast - Sf[k], eij)
	# 		Sf[k] = Sf[k] + self.graph.adj[v_i][v_j]['ef']
	# 	return Sf

	def mem_REALEQ(self, v_i, Sf, k):
		successors_node = list(self.graph.successors(v_i))
		#successors_node.sort(key=lambda x: self.graph.node[x]['workload'], reverse=True)
		if len(successors_node) > 0:
			nb_blocks = math.floor((self.size_fast - Sf[k])/len(successors_node))
		else:
			nb_blocks = self.size_fast - Sf[k]

		for v_j in successors_node:
			assert self.size_fast - Sf[k] >= 0
			eij = self.graph.adj[v_i][v_j]['weight'] # e_ij
			self.graph.adj[v_i][v_j]['ef'] = min(nb_blocks, eij)
			Sf[k] = Sf[k] + self.graph.adj[v_i][v_j]['ef']
		return Sf

	def mem_GainNode(self, v_i, Sf, k):
		successors_node = list(self.graph.successors(v_i))
		successors_node.sort(key=lambda x: self.gain_node(x), reverse=False)
		for v_j in successors_node:
			assert self.size_fast - Sf[k] >= 0
			eij = self.graph.adj[v_i][v_j]['weight'] # e_ij
			self.graph.adj[v_i][v_j]['ef'] = min(self.size_fast - Sf[k], eij)
			Sf[k] = Sf[k] + self.graph.adj[v_i][v_j]['ef']
		return Sf

	def mem_GG(self, v_i, Sf, k):
		successors_node = list(self.graph.successors(v_i))
		successors_node.sort(key=lambda x: self.gain_subgraph(x), reverse=False)
		for v_j in successors_node:
			assert self.size_fast - Sf[k] >= 0
			eij = self.graph.adj[v_i][v_j]['weight'] # e_ij
			self.graph.adj[v_i][v_j]['ef'] = min(self.size_fast - Sf[k], eij)
			Sf[k] = Sf[k] + self.graph.adj[v_i][v_j]['ef']
		return Sf

	# def mem_random(self, v_i, Sf, k):
	# 	# random.seed(self.seed)
	# 	for v_j in self.graph.successors(v_i):
	# 		assert self.size_fast - Sf[k] >= 0
	# 		eij = self.graph.adj[v_i][v_j]['weight'] # e_ij
	# 		self.graph.adj[v_i][v_j]['ef'] = random.uniform(0, min(self.size_fast - Sf[k], eij))
	# 		Sf[k] = Sf[k] + self.graph.adj[v_i][v_j]['ef']
	# 	return Sf

	def mem_inf_fast(self, v_i, Sf, k):
		for v_j in self.graph.successors(v_i):
			#assert self.size_fast - Sf[k] >= 0  #infinite number of processors
			eij = self.graph.adj[v_i][v_j]['weight'] # e_ij
			self.graph.adj[v_i][v_j]['ef'] = eij
			Sf[k] = Sf[k] + self.graph.adj[v_i][v_j]['ef']
		return Sf

	def mem_0_fast(self, v_i, Sf, k):
		for v_j in self.graph.successors(v_i):
			assert self.size_fast - Sf[k] >= 0
			self.graph.adj[v_i][v_j]['ef'] = 0
		return Sf

	__mem_heuristics__ = {mem_CP, mem_GG, mem_EQ}
	__stencil_mem_heuristics__ = {mem_CP}

	"""

	Scheduling algorithms

	"""
	def mksp(self, S):
		return max(S, key=lambda x: x[1])[1]

	#@utils.timing
	def schedule_no_tr(self, rank, iorank, verbose):
		"""
		self.graph: DAG to schedule
		rank: scheduling policy -> rank(task_list)
		iorank: memory allocation policy -> iorank(task_list)

		"""
		original_graph = self.graph.copy()
		
		k = 1
		n = self.graph.number_of_nodes()
		Sf = [0]*(2*n) #Fast memory at each used at each chunk 
		Bf = [self.bandwidth_fast]*(2*n)
		Bs = [self.bandwidth_slow]*(2*n)
		p_avail = [-1]*(2*n)
		p_avail[0] = self.proc
		L = dag.roots(self.graph)
		t = [0]*(2*n)				# Execution times (t_k)

		if verbose == 3:
			print("%66s" % (105*"-"))
			print("| %-4s | %-4s | %-15s | %-15s | %-15s | %-15s | %-15s |" % ("k", "v", "t_k", "E_i", "w_i", "in_i", "out_i"))
			print("%66s" % (105*"-"))

		while len(L) + len(model.running_tasks(self.graph, k)) > 0:
			Sf[k] = Sf[k-1]
			p_avail[k] = p_avail[k-1]

			#print("before release: p_avail[{}]={} and p_total={}".format(k, p_avail[k], self.proc))

			finished_tasks = [v_i for v_i in self.graph.nodes() if model.sigma_2(self.graph, v_i) == k]
			assert(len(finished_tasks) in [0,1]), finished_tasks
			
			for v_i in finished_tasks:
				Sf[k] = Sf[k] - sum([self.graph.adj[v_j][v_i]['ef'] for v_j in self.graph.predecessors(v_i)]) # Release input blocks
				p_avail[k] = p_avail[k] + 1 # Release processors

			#print("after release: p_avail[{}]={} and p_total={}".format(k, p_avail[k], self.proc))

			assert (Sf[k] <= self.size_fast)
			assert(0 <= p_avail[k] <= self.proc)
			rank(self, L) # Scheduling part

			while p_avail[k] > 0 and len(L) > 0:
				v_i, *tail = L
				L = tail
				Sf = iorank(self, v_i, Sf, k)
				p_avail[k] = p_avail[k] - 1
				#print("during alloc: p_avail[{}]={} and p_total={}".format(k, p_avail[k], self.proc))
				self.graph.node[v_i]['sigma_1'] = k

			assert(0 <= p_avail[k] <= self.proc)

			#The max is there to avoid to divide by 0 when no task access to slow or fast memory
			Bs[k] = self.bandwidth_slow / max(1, len(model.tasks_accessing_slow_mem(self.graph, k)))		
			Bf[k] = self.bandwidth_fast / max(1, len(model.tasks_accessing_fast_mem(self.graph, k)))

			#print("after alloc: p_avail[{}]={} and p_total={}".format(k, p_avail[k], self.proc))


			if len(model.running_tasks(self.graph,k)) > self.proc - p_avail[k]:
				print(len(model.running_tasks(self.graph,k)), self.proc - p_avail[k], p_avail[k])

			assert(len(model.running_tasks(self.graph, k)) <= self.proc - p_avail[k])

			(v_i, min_time) = model.next_finishing_task(self.graph, self.speed, k, t, Bf, Bs)

			self.graph.node[v_i]['sigma_2'] = k + 1
			t[k+1] = min_time #t_{sigma_2(i)}
			self.graph.node[v_i]['exec_time'] = min_time - t[self.graph.node[v_i]['sigma_1']] # Execution time for v_i
			self.graph.node[v_i]['t'] = min_time #makespan at that time
			#print(model.ready_tasks(self.graph, k))
			L = model.ready_tasks(self.graph, k)
			if verbose == 3:
				print("| %4d | %4s | %15.2f | %15.2f | %15.2f | %15.2f | %15.2f |" % (k, v_i, self.graph.node[v_i]['t'], self.graph.node[v_i]['exec_time'], self.graph.node[v_i]['workload'], model.total_in(self.graph, v_i), model.total_out(self.graph, v_i) ))
			k = k + 1

		if verbose == 3:
			print("%66s" % (105*"-"))
		S = [(u,edata['t']) for u,edata in self.graph.nodes(data=True)]
		self.graph = nx.DiGraph(original_graph)

		return sorted(S, key=lambda x: int(x[0]))

	def schedule_0fastmem(self, verbose):
		old_size = self.size_fast
		self.size_fast = 0
		S = self.schedule_no_tr(lambda s, L: self.CP(L), lambda s,v_i, Sf, k: self.mem_0_fast(v_i, Sf, k), verbose)
		self.size_fast = old_size
		return S

	def schedule_inffastmem(self, verbose):
		old_size = self.size_fast
		self.size_fast = math.inf
		S = self.schedule_no_tr(lambda s, L: self.CP(L), lambda s,v_i, Sf, k: self.mem_inf_fast(v_i, Sf, k), verbose)
		self.size_fast = old_size
		return S

	def schedule_inffastmem_infbandwith(self, verbose):
		old_size = self.size_fast
		self.size_fast = math.inf
		old_bandwith = self.bandwidth_fast
		self.bandwidth_fast = math.inf

		S = self.schedule_no_tr(lambda s, L: self.CP(L), lambda s,v_i, Sf, k: self.mem_inf_fast(v_i, Sf, k), verbose)
		
		self.size_fast = old_size
		self.bandwidth_fast = old_bandwith
		return S

	def schedule_as_cache_mode(self, verbose):
		"""
		self.graph: DAG to schedule
		"""
		original_graph = self.graph.copy()
		
		k = 1
		n = self.graph.number_of_nodes()
		
		#We cut the fast memory in P slices
		Sf = [0] * (self.proc)
		for chunk in range(self.proc):
			Sf[chunk] = [0]*(2*n)

		Bf = [self.bandwidth_fast]*(2*n)
		Bs = [self.bandwidth_slow]*(2*n)
		# False -> the proc_key is free, True -> proc_key is busy
		proc_map = {key: False for key in list(range(self.proc))}
		node_map = {key: -1 for key in self.graph.nodes()}

		p_avail = [-1]*(2*n)
		p_avail[0] = self.proc
		L = dag.roots(self.graph)
		t = [0]*(2*n)				# Execution times (t_k)

		if verbose == 3:
			print("%41s" % (80*"-"))
			print("| %-4s | %-4s | %-10s | %-10s | %-10s | %-10s | %-10s |" % ("k", "v", "t_k", "E_i", "w_i", "in_i", "out_i"))
			print("%41s" % (80*"-"))

		while len(L) + len(model.running_tasks(self.graph, k)) > 0:
			for p in range(self.proc):
				Sf[p][k] = Sf[p][k-1]

			p_avail[k] = p_avail[k-1]

			#print("before release: p_avail[{}]={} and p_total={}".format(k, p_avail[k], self.proc))

			finished_tasks = [v_i for v_i in self.graph.nodes() if model.sigma_2(self.graph, v_i) == k]
			assert(len(finished_tasks) in [0,1]), finished_tasks
			
			for v_i in finished_tasks:
				p_avail[k] = p_avail[k] + 1 # Release processors
				proc_done = node_map[v_i]
				node_map[v_i] = -1
				proc_map[proc_done] = False
				Sf[proc_done][k] = Sf[proc_done][k] - sum([self.graph.adj[v_j][v_i]['ef'] for v_j in self.graph.predecessors(v_i)]) # Release input blocks


			#print("after release: p_avail[{}]={} and p_total={}".format(k, p_avail[k], self.proc))

			# for p in range(self.proc):
			# 	assert (Sf[p][k] <= self.size_fast/float(self.proc) ), "Sf[%d][%d]=%f > %f" % (p, k, Sf[p][k], self.size_fast/float(self.proc))

			assert(0 <= p_avail[k] <= self.proc)

			L.sort(key=lambda x: self.get_cp(x), reverse=True) # Scheduling part

			while p_avail[k] > 0 and len(L) > 0:
				v_i, *tail = L
				L = tail
				for (p,state) in proc_map.items():
					if state == False:
						proc_choose = p
						break

				node_map[v_i] = proc_choose
				proc_map[proc_choose] = True
				p_avail[k] = p_avail[k] - 1

				#Try to fulfill the chunk of size Sf/P
				successors_node = list(self.graph.successors(v_i))
				for v_j in successors_node:
					eij = self.graph.adj[v_i][v_j]['weight'] # e_ij
					self.graph.adj[v_i][v_j]['ef'] = min(math.floor(self.size_fast/float(self.proc)) - Sf[proc_choose][k], eij)
					Sf[proc_choose][k] = Sf[proc_choose][k] + self.graph.adj[v_i][v_j]['ef']

				#print("during alloc: p_avail[{}]={} and p_total={}".format(k, p_avail[k], self.proc))
				self.graph.node[v_i]['sigma_1'] = k

			assert(0 <= p_avail[k] <= self.proc)

			#The max is there to avoid to divide by 0 when no task access to slow or fast memory
			Bs[k] = self.bandwidth_slow / max(1, len(model.tasks_accessing_slow_mem(self.graph, k)))		
			Bf[k] = self.bandwidth_fast / max(1, len(model.tasks_accessing_fast_mem(self.graph, k)))

			#print("after alloc: p_avail[{}]={} and p_total={}".format(k, p_avail[k], self.proc))


			if len(model.running_tasks(self.graph,k)) > self.proc - p_avail[k]:
				print(len(model.running_tasks(self.graph,k)), self.proc - p_avail[k], p_avail[k])

			assert(len(model.running_tasks(self.graph, k)) <= self.proc - p_avail[k])

			(v_i, min_time) = model.next_finishing_task(self.graph, self.speed, k, t, Bf, Bs)

			self.graph.node[v_i]['sigma_2'] = k + 1
			t[k+1] = min_time #t_{sigma_2(i)}
			self.graph.node[v_i]['exec_time'] = min_time - t[self.graph.node[v_i]['sigma_1']] # Execution time for v_i
			self.graph.node[v_i]['t'] = min_time #makespan at that time
			#print(model.ready_tasks(self.graph, k))
			L = model.ready_tasks(self.graph, k)
			if verbose == 3:
				print("| %4d | %4s | %10.2f | %10.2f | %10.2f | %10.2f | %10.2f |" % (k, v_i, self.graph.node[v_i]['t'], self.graph.node[v_i]['exec_time'], self.graph.node[v_i]['workload'], model.total_in(self.graph, v_i), model.total_out(self.graph, v_i) ))
			k = k + 1

		if verbose == 3:
			print("%41s" % (80*"-"))
		S = [(u,edata['t']) for u,edata in self.graph.nodes(data=True)]
		self.graph = nx.DiGraph(original_graph)

		return sorted(S, key=lambda x: int(x[0]))


	def bottom_level_fast(self, v, verbose):
		"""
		self.graph: DAG to schedule
		"""
		original_graph = self.graph.copy()
		old_size_fast = self.size_fast
		old_proc = self.proc

		self.graph = dag.rooted_subgraph(original_graph, v)		
		self.size_fast = math.inf
		self.proc = math.inf

		if len(self.graph) <= 1:
			self.graph = nx.DiGraph(original_graph)
			self.size_fast = old_size_fast
			self.proc = old_proc
			return [(v,self.gain_node(v))]

		k = 1
		n = self.graph.number_of_nodes()
		Sf = [0]*(2*n)
		Bf = [self.bandwidth_fast]*(2*n)
		Bs = [self.bandwidth_slow]*(2*n)
		p_avail = [-1]*(2*n)
		p_avail[0] = self.proc
		L = dag.roots(self.graph)
		t = [0]*(2*n)				# Execution times (t_k)

		if verbose == 4:
			print("%41s" % (80*"-"))
			print("| %-4s | %-4s | %-10s | %-10s | %-10s | %-10s | %-10s |" % ("k", "v", "t_k", "E_i", "w_i", "in_i", "out_i"))
			print("%41s" % (80*"-"))

		while len(L) + len(model.running_tasks(self.graph, k)) > 0:
			Sf[k] = Sf[k-1]
			p_avail[k] = p_avail[k-1]

			#print("before release: p_avail[{}]={} and p_total={}".format(k, p_avail[k], self.proc))

			finished_tasks = [v_i for v_i in self.graph.nodes() if model.sigma_2(self.graph, v_i) == k]
			assert(len(finished_tasks) in [0,1]), finished_tasks
			
			for v_i in finished_tasks:
				Sf[k] = Sf[k] - sum([self.graph.adj[v_j][v_i]['ef'] for v_j in self.graph.predecessors(v_i)]) # Release input blocks
				p_avail[k] = p_avail[k] + 1 # Release processors

			#print("after release: p_avail[{}]={} and p_total={}".format(k, p_avail[k], self.proc))

			assert (Sf[k] <= self.size_fast), "%f %f" % (Sf[k], self.size_fast)
			assert(0 <= p_avail[k] <= self.proc)
			# rank_EFT(L) # Scheduling part
			# L.sort(key=lambda x: int(x))

			while p_avail[k] > 0 and len(L) > 0:
				v_i, *tail = L
				L = tail
				Sf = self.mem_inf_fast(v_i, Sf, k)
				p_avail[k] = p_avail[k] - 1
				#print("during alloc: p_avail[{}]={} and p_total={}".format(k, p_avail[k], self.proc))
				self.graph.node[v_i]['sigma_1'] = k

			assert(0 <= p_avail[k] <= self.proc)

			#The max is there to avoid to divide by 0 when no task access to slow or fast memory
			Bs[k] = self.bandwidth_slow / max(1, len(model.tasks_accessing_slow_mem(self.graph, k)))		
			Bf[k] = self.bandwidth_fast / max(1, len(model.tasks_accessing_fast_mem(self.graph, k)))

			#print("after alloc: p_avail[{}]={} and p_total={}".format(k, p_avail[k], self.proc))


			# if len(model.running_tasks(self.graph,k)) >= self.proc - p_avail[k]:
			#print(len(model.running_tasks(self.graph,k)), self.proc - p_avail[k], p_avail[k])

			#assert(len(model.running_tasks(self.graph, k)) <= self.proc - p_avail[k])

			(v_i, min_time) = model.next_finishing_task(self.graph, self.speed, k, t, Bf, Bs)

			self.graph.node[v_i]['sigma_2'] = k + 1
			t[k+1] = min_time #t_{sigma_2(i)}
			self.graph.node[v_i]['exec_time'] = min_time - t[self.graph.node[v_i]['sigma_1']] # Execution time for v_i
			self.graph.node[v_i]['t'] = min_time #makespan at that time
			#print(model.ready_tasks(self.graph, k))
			L = model.ready_tasks(self.graph, k)
			if verbose == 4:
				print("| %4d | %4s | %10.2f | %10.2f | %10.2f | %10.2f | %10.2f |" % (k, v_i, self.graph.node[v_i]['t'], self.graph.node[v_i]['exec_time'], self.graph.node[v_i]['workload'], model.total_in(self.graph, v_i), model.total_out(self.graph, v_i) ))
			k = k + 1

		if verbose == 4:
			print("%41s" % (80*"-"))
		S = [(u,edata['t']) for u,edata in self.graph.nodes(data=True)]

		self.graph = nx.DiGraph(original_graph)
		self.size_fast = old_size_fast
		self.proc = old_proc

		return sorted(S, key=lambda x: int(x[0]))


	def bottom_level_slow(self, v, verbose):
		"""
		self.graph: DAG to schedule
		"""
		original_graph = self.graph.copy()
		old_size_fast = self.size_fast
		old_proc = self.proc

		self.graph = dag.rooted_subgraph(original_graph, v)

		if len(self.graph) <= 1:
			self.graph = nx.DiGraph(original_graph)
			self.size_fast = old_size_fast
			self.proc = old_proc
			return [(v, self.gain_node(v))]

		# zozoz = dag.rooted_subgraph(self.graph, v)
		# H_nodes = nx.dfs_preorder_nodes(self.graph, v)
		# H = self.graph.subgraph(H_nodes).copy()

		# print(H.nodes())
		# print(zozoz.nodes())

		self.size_fast = 0
		self.proc = math.inf

		k = 1
		n = self.graph.number_of_nodes()
		Sf = [0]*(2*n)
		Bf = [self.bandwidth_fast]*(2*n)
		Bs = [self.bandwidth_slow]*(2*n)
		p_avail = [-1]*(2*n)
		p_avail[0] = self.proc
		L = dag.roots(self.graph)
		t = [0]*(2*n)				# Execution times (t_k)

		if verbose == 4:
			print(self.graph.nodes(), v)
			print("%41s" % (80*"-"))
			print("| %-4s | %-4s | %-10s | %-10s | %-10s | %-10s | %-10s |" % ("k", "v", "t_k", "E_i", "w_i", "in_i", "out_i"))
			print("%41s" % (80*"-"))

		while len(L) + len(model.running_tasks(self.graph, k)) > 0:
			Sf[k] = Sf[k-1]
			p_avail[k] = p_avail[k-1]

			#print("before release: p_avail[{}]={} and p_total={}".format(k, p_avail[k], self.proc))

			finished_tasks = [v_i for v_i in self.graph.nodes() if model.sigma_2(self.graph, v_i) == k]
			assert(len(finished_tasks) in [0,1]), finished_tasks
			
			# for v_i in finished_tasks:
			# 	Sf[k] = Sf[k] - sum([self.graph.adj[v_j][v_i]['ef'] for v_j in self.graph.predecessors(v_i)]) # Release input blocks
			# 	p_avail[k] = p_avail[k] + 1 # Release processors

			#print("after release: p_avail[{}]={} and p_total={}".format(k, p_avail[k], self.proc))

			# assert (Sf[k] <= self.size_fast), "%f %f" % (Sf[k], self.size_fast)
			# assert(0 <= p_avail[k] <= self.proc)
			#rank_EFT(L) # Scheduling part
			#L.sort(key=lambda x: int(x))

			while len(L) > 0:
				v_i, *tail = L
				L = tail
				Sf = self.mem_0_fast(v_i, Sf, k)
				# p_avail[k] = p_avail[k] - 1
				#print("during alloc: p_avail[{}]={} and p_total={}".format(k, p_avail[k], self.proc))
				self.graph.node[v_i]['sigma_1'] = k

			# assert(0 <= p_avail[k] <= self.proc)

			#The max is there to avoid to divide by 0 when no task access to slow or fast memory
			Bs[k] = self.bandwidth_slow / max(1, len(model.tasks_accessing_slow_mem(self.graph, k)))		
			Bf[k] = self.bandwidth_fast / max(1, len(model.tasks_accessing_fast_mem(self.graph, k)))

			#print("after alloc: p_avail[{}]={} and p_total={}".format(k, p_avail[k], self.proc))


			#if len(model.running_tasks(self.graph,k)) > self.proc - p_avail[k]:
				#print(len(model.running_tasks(self.graph,k)), self.proc - p_avail[k], p_avail[k])

			#assert(len(model.running_tasks(self.graph, k)) <= self.proc - p_avail[k])

			(v_i, min_time) = model.next_finishing_task(self.graph, self.speed, k, t, Bf, Bs)

			self.graph.node[v_i]['sigma_2'] = k + 1
			t[k+1] = min_time #t_{sigma_2(i)}
			self.graph.node[v_i]['exec_time'] = min_time - t[self.graph.node[v_i]['sigma_1']] # Execution time for v_i
			self.graph.node[v_i]['t'] = min_time #makespan at that time
			#print(model.ready_tasks(self.graph, k))
			L = model.ready_tasks(self.graph, k)
			if verbose == 4:
				print("| %4d | %4s | %10.2f | %10.2f | %10.2f | %10.2f | %10.2f |" % (k, v_i, self.graph.node[v_i]['t'], self.graph.node[v_i]['exec_time'], self.graph.node[v_i]['workload'], model.total_in(self.graph, v_i), model.total_out(self.graph, v_i) ))
			k = k + 1

		if verbose == 4:
			print("%41s" % (80*"-"))
		S = [(u,edata['t']) for u,edata in self.graph.nodes(data=True)]
		
		self.graph = nx.DiGraph(original_graph)
		self.size_fast = old_size_fast
		self.proc = old_proc

		return sorted(S, key=lambda x: int(x[0]))
