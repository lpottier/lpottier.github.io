#!/usr/bin/env python3

import sys
import os
import fnmatch
import argparse
import networkx as nx
import csv
import itertools
import math
from statistics import mean,median,stdev
from pathlib import Path
from timeit import default_timer as timer
import datetime
import socket
import time

import utils
#import drawing_dag
import dag
import model
import sim

import matplotlib.pyplot as plt

#Look into a dir to detect the size of the dot files inside
def get_size_dot(dir_dot):
	files = fnmatch.filter(os.listdir(dir_dot), '*.dot')
	H = nx.nx_agraph.read_dot(path=os.path.join(dir_dot, files[0]))
	return H.number_of_nodes() - 2 #Remove two, one for the source/puit

def print_args(args, file):
	with open(file, 'w') as f:
		f.write('## Configuration\n')
		f.write('## simulation date={}\n'.format(datetime.datetime.now().strftime("%d-%m-%y")))
		f.write('## simulation time={}\n'.format(datetime.datetime.now().strftime("%H:%M:%S")))
		f.write('## host={}\n'.format(socket.gethostname()))
		for arg in vars(args):
			f.write('{}={}\n'.format(arg, getattr(args, arg) ) )

def stencil1D_jacobi(k, ntiles, nstep, size_tile, work, entry=True, exit=True):
	stencil_id = 'stencil{message:{fill}{align}{width}}'.format(
		message=str(k), fill='0', align='>', width=4)

	print("{}".format(stencil_id))

	n = nstep * (3 * ntiles) + 2 #one entry and exit target

	G = nx.DiGraph(name=stencil_id)
	nodes = [str(i) for i in range(n)]
	G.add_nodes_from(nodes)
	w_i = {str(u):0 for u in nodes}

	# Connect the entry node
	elist = [('0', str(x), int(size_tile)) for x in range(1, 3*ntiles+1, 3)]

	print("nstep =\t\t\t{}\nntile =\t\t\t{}\nnode per tile =\t\t{}".format(nstep, ntiles, 3*ntiles))

	for step in range(nstep):
		begin_step_i = step*(3*ntiles)+1
		end_step_i = (step+1)*(3*ntiles)
		node_in_step = range(begin_step_i, end_step_i, 3)
		node_in_step_last_line = list(map(lambda x: x+2, node_in_step))

		# print(begin_step_i,  end_step_i, list(node_in_step), node_in_step_last_line)
		# print("--")

		for i in node_in_step:
			#we connect R_i to C_i
			elist += [( str(i),str(i+1),0 )]
			#we connect C_i to W_i
			elist += [( str(i+1),str(i+2),0 )]

			w_i[str(i+1)] = work

			if step == nstep-1:
				#we connect the all W_i of the last step to the exit node
				elist += [( str(i+2), str(n-1), int(size_tile) )]


		if step < nstep-1:
			last_begin_line = (step+1)*(3*ntiles)+1
			last_end_line  = (step+2)*(3*ntiles)
			begin_next_line = list(range(last_begin_line, last_end_line, 3))

			#we connect each W^(t-1)_i to R^t_(i-1)
			elist += [(str(u),str(v),1) for (u,v) in zip(node_in_step_last_line, begin_next_line)]

			#we connect each W^(t-1)_i to R^t_i
			#We shift from right
			node_in_step_last_line_left = node_in_step_last_line[1:]
			#We shift from left
			begin_next_line_left = begin_next_line[:-1]
			elist += [(str(u),str(v),int(size_tile)) for (u,v) in zip(node_in_step_last_line_left, begin_next_line_left)]

			#we connect each W^(t-1)_i to R^t_(i+1)
			#We shift from right
			node_in_step_last_line_right = node_in_step_last_line[:-1]
			#We shift from left
			begin_next_line_right = begin_next_line[1:]
			elist += [(str(u),str(v), 1) for (u,v) in zip(node_in_step_last_line_right, begin_next_line_right)]

	G.add_weighted_edges_from(elist, weight='weight')
	nx.set_node_attributes(G, name='workload', values=w_i)

	# print(G.nodes(data=True))

	return G


def stencil1D_laplacien(k, ntiles, nstep, size_tile, work, entry=True, exit=True):
	stencil_id = 'stencil{message:{fill}{align}{width}}'.format(
		message=str(k), fill='0', align='>', width=4)

	print("{}".format(stencil_id))

	n = nstep * (3 * ntiles)

	#one entry and exit target
	if entry:
		n = n + 1
	if exit:
		n = n + 1

	G = nx.DiGraph(name=stencil_id)

	nodes = [str(i) for i in range(n)]
	G.add_nodes_from(nodes)
	w_i = {str(u):0 for u in nodes}

	elist = []
	if entry:
		# Connect the entry node
		elist += [('0', str(x), int(size_tile)) for x in range(1, 3*ntiles+1, 3)]

	print("nstep =\t\t\t{}\nntile =\t\t\t{}\nnode per tile =\t\t{}".format(nstep, ntiles, 3*ntiles))

	for step in range(nstep):
		begin_step_i = step*(3*ntiles)+1
		end_step_i = (step+1)*(3*ntiles)
		node_in_step = range(begin_step_i, end_step_i, 3)
		node_in_step_mid_line = list(map(lambda x: x+1, node_in_step))
		node_in_step_last_line = list(map(lambda x: x+2, node_in_step))

		# print(begin_step_i,  end_step_i, list(node_in_step), node_in_step_mid_line, node_in_step_last_line)
		# print("--")

		elist += [( str(node_in_step[u]),str(node_in_step[u+1]), 0 ) for u in range(len(node_in_step[:-1]))]
		elist += [( str(node_in_step_mid_line[u]),str(node_in_step_mid_line[u+1]), 0 ) for u in range(len(node_in_step_mid_line[:-1]))]
		elist += [( str(node_in_step_last_line[u]),str(node_in_step_last_line[u+1]), 0 ) for u in range(len(node_in_step_last_line[:-1]))]

		for i in node_in_step:
			#we connect R_i to C_i
			elist += [( str(i),str(i+1), 0 )]
			#we connect C_i to W_i
			elist += [( str(i+1),str(i+2), 0 )]

			#set computational cost for C_i
			w_i[str(i+1)] = work

			if step == nstep-1 and exit:
				#we connect the all W_i of the last step to the exit node
				elist += [( str(i+2), str(n-1), int(size_tile) )]

		if step < nstep-1:
			last_begin_line = (step+1)*(3*ntiles)+1
			last_end_line  = (step+2)*(3*ntiles)
			begin_next_line = list(range(last_begin_line, last_end_line, 3))

			#we connect each W^(t-1)_i to R^t_(i-1)
			elist += [(str(u),str(v), int(size_tile)) for (u,v) in zip(node_in_step_last_line, begin_next_line)]

	G.add_weighted_edges_from(elist, weight='weight')
	nx.set_node_attributes(G, name='workload', values=w_i)

	return G

#@utils.timing
def main(args):
	if args.verbose == None:
		args.verbose = -1


	baseline_bandwith=90.0*1e9 # Bandwidth slow in B/s
	w_start = math.floor( (args.ccr*args.processor_speed*args.size_tiles)/(args.bandwidth_fast*baseline_bandwith) )
	ratio = args.processor_speed/baseline_bandwith
	#w_start = math.floor( (args.ccr*ratio*args.size_tiles) * (2.0/3.0) )

	G = stencil1D_laplacien(k=0, 
		ntiles=args.nb_tiles, 
		nstep=args.nb_iterations, 
		size_tile=args.size_tiles, 
		work=w_start)

	dag_name = G.graph['name']
	theseed = 0

	nx.set_edge_attributes(G, name='n', values=1)
	nx.set_node_attributes(G, name='sigma_1', values=sys.maxsize) 		#set sigma_1(i) to +oo
	nx.set_node_attributes(G, name='sigma_2', values=sys.maxsize) 		#set sigma_2(i) to +oo
	nx.set_edge_attributes(G, name='ef', values=0) 

	nb_node = G.number_of_nodes()-2

	# Create output directory (if not specified it's a 'build/' into the src directory)
	name_exp = dag_name+'_iter-'+str(args.nb_iterations)+'_tile-'+str(args.nb_tiles)+'_p-'+str(args.nb_processors)+'_sf-'+str(args.size_fast)+'_bf-'+str(args.bandwidth_fast)+'_ccr-'+str(args.ccr)

	default_ouput = os.path.join(args.output_dir, name_exp)
	if not os.path.exists(default_ouput):
		os.makedirs(default_ouput)

	print_args(args, os.path.join(default_ouput, 'configuration.sim'))

	A = nx.nx_agraph.to_agraph(G)
	A.layout(prog='sfdp')
	A.draw(os.getcwd()+"/stencil.dot")

	csvres = open(default_ouput+'/'+name_exp+'_seed-'+str(theseed)+'.csv', newline='', mode='w')
	csvwriter = csv.writer(csvres, delimiter=',',
									quotechar='|', 
									quoting=csv.QUOTE_MINIMAL)
	csvwriter.writerow(['DAG', 'N', 'P', 'BF', 'SF', 'SPEED', 'CCR', 'HEURISTIC', 'MKSP', 'AVG'])
	mksp = []
	best_gain = {}

	simu =  sim.Simulation(
		name=name_exp,
		ggen=None,
		graph=G,
		proc=args.nb_processors, 
		speed=args.processor_speed, 
		size_fast=args.size_fast,
		bandwidth_fast=args.bandwidth_fast*baseline_bandwith,
		bandwidth_slow=1.0*baseline_bandwith, 
		seed=theseed,
		dotfile=True
	)

	#Compute the name of all heuristics used in this order (the order is important)
	proc_name = list(map(lambda x: str(x.__name__).upper(), simu.__stencil_proc_heuristics__))
	mem_name = list(map(lambda x: str(x.__name__).upper(), simu.__stencil_mem_heuristics__))
	name_heuristics = list(itertools.product(proc_name, mem_name))
	#name_heuristics = ["CP+NO_FAST"]+["CP+CC_MODE"]+list(map(lambda x: x[0]+'+'+x[1], name_heuristics))
	#name_heuristics = ["CP+NO_FAST"]+["CP+CC_MODE"]+["CP+INF_FAST"]+["CP+INFFAST_INFBF"]+list(map(lambda x: x[0]+'+'+x[1], name_heuristics))
	name_heuristics = ["CP+NO_FAST"]+list(map(lambda x: x[0]+'+'+x[1], name_heuristics))
	simu.set_seed(theseed)

	if args.verbose >= 1:
		print (simu, "\n")

	if args.verbose >= 2:
		print ("[{}] CCR={} | W={}, E={}".format(time.strftime("%Y-%m-%d %H:%M:%S"),args.ccr, w_start/args.processor_speed, args.size_tiles/baseline_bandwith) )

	if not args.print_graphs:
		output_dot = default_ouput+'/graph_'+name_exp+'.dot'
		output_pdf = default_ouput+'/graph_'+name_exp+'.pdf'
		if args.verbose >= 2:
			print("Writing dot file... ", output_dot)
		nx.nx_agraph.write_dot(simu.graph, output_dot)
		#drawing_dag.draw(G, output_pdf)

	if args.verbose >= 2:
		print("Computing critical paths...")
	simu.compute_cp()
	if args.verbose >= 2:
		print("Starting simulations...")
	res = []
	cte = [nb_node, args.nb_processors, args.bandwidth_fast, args.size_fast, args.processor_speed, args.ccr]
	

	if args.verbose >= 2:
		print("[{}] Compute the performance without slow memory...".format(time.strftime("%Y-%m-%d %H:%M:%S")))		
	#Compute the performance without slow memory
	S = simu.schedule_0fastmem(args.verbose)
	mksp.append(simu.mksp(S))
	# print(S)

	# if args.verbose >= 2:
	# 	print("[{}] Compute the cache mode baseline...".format(time.strftime("%Y-%m-%d %H:%M:%S")))	
	# #Compute the cache mode baseline
	# S = simu.schedule_as_cache_mode(args.verbose)
	# mksp.append(simu.mksp(S))

	# if args.verbose >= 2:
	# 	print("[{}] Compute the performance with infinite fast memory...".format(time.strftime("%Y-%m-%d %H:%M:%S")))	
	# #Compute the performance with infinite fast memory
	# S = simu.schedule_inffastmem(args.verbose)
	# mksp.append(simu.mksp(S))

	# if args.verbose >= 2:
	# 	print("[{}] Compute the performance with infinite fast memory and infinite bandwidth...".format(time.strftime("%Y-%m-%d %H:%M:%S")))
	# #Compute the performance with infinite fast memory and infinite bandwidth
	# S = simu.schedule_inffastmem_infbandwith(args.verbose)
	# mksp.append(simu.mksp(S))

	#All heuristics
	for hproc in simu.__stencil_proc_heuristics__:
		for hmem in simu.__stencil_mem_heuristics__:
			if args.verbose >= 2:
				print("[{}] Compute the performance with {}...".format(time.strftime("%Y-%m-%d %H:%M:%S"), hproc.__name__.upper()+'+'+hmem.__name__.upper()))
			# We compute the schedule according an scheduling heuristic and a memory allocation heuristic
			S = simu.schedule_no_tr(hproc, hmem, args.verbose)
			# print(S)
			mksp.append(simu.mksp(S))
		#end for hmem
	#end for hproc

	for j in range(len(name_heuristics)):
		csvwriter.writerow([dag_name]+cte+[name_heuristics[j], mksp[j], 1])
	
	i = 0
	print('{:<30} {:<25} {:<25}'.format("HEURISTIC", "MKSP", "NORMALIZATION"))
	for h in name_heuristics:
		print('{:<30} {:<25} {:<25}'.format(h, mksp[i], mksp[i]/mksp[0]))
		i = i + 1



if __name__ == "__main__":
	# G = stencil1D_laplacien(k=1, ntiles=2, nstep=2, size_tile=100, work=1)
	# print(G.nodes(data=True))
	# print(G.edges(data=True))
	# A = nx.nx_agraph.to_agraph(G)
	# A.layout(prog='dot')
	# current_dir = os.getcwd()
	# A.draw(current_dir+"/stencil.dot")


	current_dir = os.getcwd()
	parser = argparse.ArgumentParser()
	parser.add_argument('-o', '--output-dir', type=str, nargs='?', default='build-stencil', required=False, help="Output directory (by default the current directory is used)")

	parser.add_argument('-i', '--nb-iterations', type=int, nargs='?', default=1, required=True, help="Number of iterations of the stencil")
	parser.add_argument('-t', '--nb-tiles', type=int, nargs='?', default=1, required=True, help="Number of tiles in one iteration")
	parser.add_argument('--size-tiles', type=float, nargs='?', required=True, help="Size of one tile in Byte")

	parser.add_argument('-p', '--nb-processors', type=int, default=1, required=True, help="Number of processors")
	parser.add_argument('-b', '--bandwidth-fast', type=float, nargs='?', default=5.0, required=True, help="Fast bandwidth speed")
	parser.add_argument('-c', '--size-fast', type=float, nargs='?', default=0, required=True, help="Fast memory size")
	parser.add_argument('-s', '--processor-speed', type=float, nargs='?', default=1.4e+9, required=True, help="Processors speed")
	parser.add_argument('--ccr', type=float, nargs='?', default=1.0, required=False, help="Computation/communication ratio")

	parser.add_argument('-v', '--verbose', type=int, nargs='?', default=-1, required=False, help="Verbose output [0,1,2,3]")
	parser.add_argument('--print-graphs', type=bool, nargs='?', default=True, required=False, help="Create graphs and Gantt charts (to output directory)")

	args = parser.parse_args()

	main(args)
