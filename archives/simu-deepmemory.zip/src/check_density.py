#!/usr/bin/env python3

import os
import shutil
import fnmatch
import operator
from collections import OrderedDict
import argparse
import networkx as nx

def main(args):
	density = {}
	files = fnmatch.filter(os.listdir(args.input_dir), '*.dot')
	if len(files) == 0:
		print("No dot files in {}".format(args.input_dir))
		exit()

	for dot in files:
		H = nx.nx_agraph.read_dot(path=os.path.join(args.input_dir, dot))
		G = nx.DiGraph()
		G.add_nodes_from(H.nodes(data=False))
		G.add_edges_from(H.edges(data=False))
		density[dot] = nx.density(G)

	if args.range is None:
		args.range = [0, len(files)]

	sorted_density = OrderedDict(sorted(density.items(), key=operator.itemgetter(1), reverse=args.dense))
	if args.pretty_print and not args.no_print:
		i = 0
		# if not args.full_path:
		# 	size = len(args.input_dir)
		# 	print('| num:{fill}{width} | {} |'.format('graph', 'density', width=size))
		# else:
		# 	print('| {} | {} |'.format('graph', 'density'))
		size_max = len(str(args.range[1]))
		for (g,d) in sorted_density.items():
			if not args.full_path:
				dag = os.path.join(args.input_dir, g)
			else:
				dag = g
			if i >= args.range[0] and i <= args.range[1]:
				print('| {num:{width}} | {} | {:.3f} |'.format(dag, d, num=i, width=size_max,))
			i = i + 1

	elif not args.pretty_print and not args.no_print:
		res = list(sorted_density.keys())[args.range[0]:args.range[1]]
		if not args.full_path:
			res = [os.path.join(args.input_dir, g) for g in res]
		else:
			print(*res)

	if args.output_dir is not None:
		if not os.path.exists(args.output_dir):
			os.makedirs(args.output_dir)
		i = 0
		for (g,d) in sorted_density.items():
			dag = os.path.join(args.input_dir, g)
			if i >= args.range[0] and i <= args.range[1]:
				if args.annotate:
					shutil.copy(dag, os.path.join(args.output_dir,os.path.splitext(g)[0]+'-'+str(i)+os.path.splitext(g)[1]))
				else:
					shutil.copy(dag, args.output_dir)
			i = i + 1


if __name__ == "__main__":
	parser = argparse.ArgumentParser()
	parser.add_argument('-i', '--input-dir', type=str, nargs='?', required=True, help="Input directory")
	parser.add_argument('-o', '--output-dir', type=str, nargs='?', required=False, help="Output directory")
	parser.add_argument('-r', '--range', type=int, nargs=2, default=None, required=False, help="The number of DAG processed")
	parser.add_argument('--pretty-print', action='store_true', required=False, help="Pretty print")
	parser.add_argument('--no-print', action='store_true', required=False, help="No print")
	parser.add_argument('--full-path', type=bool, nargs='?', default=True, required=False, help="Produce full path")
	parser.add_argument('--dense', action='store_true', required=False, help="Sort by descending order of density")
	parser.add_argument('--annotate', action='store_true', required=False, help="Add the rank of the graph according its density in its filename")

	args = parser.parse_args()

	if args.no_print and args.pretty_print:
		args.pretty_print = False

	main(args)
