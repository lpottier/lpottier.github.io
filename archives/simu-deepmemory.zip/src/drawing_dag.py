#!/usr/bin/env python3

import os
import sys
import networkx as nx
import pygraphviz as pgv
import graphviz as gv
import warnings
warnings.filterwarnings("ignore")

import matplotlib as mpl
import matplotlib.pyplot as plt
#import matplotlib2tikz as plt_tikz

import numpy as np

import model
import utils

mpl.use('Cairo', warn=False, force=False)
#plt.style.use('bmh')
plt.rc('text', usetex=True)
plt.rc('font', family='Computer Modern', size='10')

def draw(G, file_out):
	A = nx.nx_agraph.to_agraph(G)
	A.layout(prog='dot')
	A.draw(file_out)

def draw_pretty(G, file_out):
	pos = nx.nx_agraph.pygraphviz_layout(G, prog='dot')
	nx.drawing.draw(G, pos, node_color='b')
	limits = plt.axis('off')
	plt.savefig(file_out)

def draw_all(G, dir_out):
    try:
        if not os.path.exists(dir_out):
            os.makedirs(dir_out)

        f = dir_out+'/'+G.graph['name']

        draw(G, f+'_graphviz'+'.pdf')
        print("[ok] drawing_dag: writing graphviz", file=sys.stderr)

        draw_pretty(G, f+'_matplotlib'+'.pdf')
        print("[ok] drawing_dag: writing matplotlib", file=sys.stderr)

        #draw_tikz(G, f+'.tex')
        #print("[ok] drawing_dag: writing tikz", file=sys.stderr)

        #make_standalone_tikz(f+'.tex', f+'_standalone'+'.tex')
        #print("[ok] drawing_dag: writing standalone tikz", file=sys.stderr)

        ganttchart(G, f+'_ganttchart'+'.pdf')
        print("[ok] drawing_dag: writing Gantt chart", file=sys.stderr)

    except OSError as e:
        print("[error] drawing_dag:", os.strerror(e.errno), file=sys.stderr)

### Export tikz

def make_standalone_tikz(f_in, f_out, lua_latex=False):
    with open(f_in, 'r') as original:
        data = original.read()
    with open(f_out, 'w') as myfile:
        myfile.write("\\documentclass[crop,tikz]{standalone}\n")
        myfile.write("\\usepackage[utf8]{inputenc}\n")
        if lua_latex:
            myfile.write("\\usepackage{fontspec} % This line only for XeLaTeX and LuaLaTeX\n")
        else:
            myfile.write("%\\usepackage{fontspec} % This line only for XeLaTeX and LuaLaTeX\n")
        myfile.write("\\usepackage{pgfplots}\n")
        myfile.write("\\usetikzlibrary{plotmarks}\n\n")
        myfile.write("\\begin{document}\n")
        myfile.write(data)
        myfile.write("\\end{document}\n")

# def draw_tikz(G, file_out):
# 	pos = nx.nx_agraph.pygraphviz_layout(G, prog='dot')
# 	nx.drawing.draw(G, pos)
# 	limits = plt.axis('off')
# 	plt_tikz.save(file_out)



def ganttchart(G, file_out):
    sigma_1=[(u,edata['sigma_1']) for u,edata in G.nodes(data=True) if 'sigma_1' in edata]
    sigma_2=[(u,edata['sigma_2']) for u,edata in G.nodes(data=True) if 'sigma_2' in edata]

    ylabels = list(map(int, G.nodes()))

    ilen = max(sigma_2, key=lambda x: x[1])[1]

    pos = np.arange(0.5, (ilen-1)*0.5+0.5, 0.5)

    fig = plt.figure()
    ax = fig.add_subplot(111)

    locsy, labelsy = plt.yticks(pos, ylabels)
    #plt.setp(labelsy, fontsize = 14)
    #ax.axis('tight')
    ax.set_ylim(ymin = 0, ymax = (ilen-1)*0.5+0.5)
    ax.set_xlim(xmin = 1, xmax = ilen)

    ax.set_xlabel(r'$\sigma_1,\ \sigma_2$')
    ax.set_ylabel('Tasks')
    ax.set_axisbelow(True)
    ax.grid(color = 'gray', linestyle = ':')
    ax.xaxis.grid(True)
    ax.yaxis.grid(False)

    box = ax.get_position()
    ax.set_position([box.x0, box.y0, box.width * 0.95, box.height])

    mem_fast = int(G.graph['fast_mem'])
    tic_mem = list(range(0, mem_fast))
    ax1 = fig.add_axes([0.88, box.y0, box.width * 0.05, box.height])
    cmap = mpl.cm.coolwarm
    #norm = mpl.colors.Normalize(vmin=0, vmax=mem_fast)
    cmap.set_under('purple')
    cmap.set_over('purple')
    cb1 = mpl.colorbar.ColorbarBase(ax1, cmap=cmap, orientation='vertical')
    cb1.set_label('Fast Memory')

    for (start,end) in zip(sigma_1, sigma_2):
        #print(start,end)
        i = int(start[0])
        if mem_fast <= 0:
        	mem_fast = 1
        frac_mem_fast = (model.in_f(G, start[0])+model.out_f(G, start[0])) / mem_fast
        ax.barh((i*0.5)+0.5, end[1] - start[1], left=start[1], height=0.5, 
            align='center', edgecolor='gray', color=cmap(frac_mem_fast), alpha = 1)
        ax.text(i+1.5, int(end[0])*0.5+0.5,
                '%.2f' % float(frac_mem_fast),
                ha='center', va='center')
        

    #ax.legend(loc=1)
 
    plt.savefig(file_out)
    #plt.show()



