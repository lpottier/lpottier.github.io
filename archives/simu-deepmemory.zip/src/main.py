#!/usr/bin/env python3

import sys
import os
import fnmatch
import argparse
import networkx as nx
import csv
import itertools
import math
from statistics import mean,median,stdev
from pathlib import Path
from timeit import default_timer as timer
import datetime
import socket

import utils
#import drawing_dag
import dag
import model
import sim

# TODO: 
# 	- [x]: Baseline algorithms (greedy mem)
# 	- [x]: EFT, HFT, MaxGainNode and MaxGainGraph
# 	- [x]: MemGainNode, MemGainGraph, MemCP and MemFair
# 	- [x]: remove recursion in critical paths computation (too slow)
# 	- [x]: Scripts bash to run automatically simulations
# 	- [ ]: module to directly process the data
# 	- [ ]: module for plotting
# 	- [x]: Test with random DAG
# 	- [x]: Check running time for X runs (to average random runs)

# 	- [ ]: Implement data transfers?

# def read_conf_file(conf_file):
# 	with open(conf_file, 'r'):

#Look into a dir to detect the size of the dot files inside
def get_size_dot(dir_dot):
	files = fnmatch.filter(os.listdir(dir_dot), '*.dot')
	H = nx.nx_agraph.read_dot(path=os.path.join(dir_dot, files[0]))
	return H.number_of_nodes() - 2 #Remove two, one for the source/puit

def print_args(args, file):
	with open(file, 'w') as f:
		f.write('## Configuration\n')
		f.write('## simulation date={}\n'.format(datetime.datetime.now().strftime("%d-%m-%y")))
		f.write('## simulation time={}\n'.format(datetime.datetime.now().strftime("%H:%M:%S")))
		f.write('## host={}\n'.format(socket.gethostname()))
		for arg in vars(args):
			f.write('{}={}\n'.format(arg, getattr(args, arg) ) )

#@utils.timing
def main(args):
	if args.verbose == None:
		args.verbose = -1

	nb_node = get_size_dot(args.dot_dir)
	name_exp = 'n-'+str(nb_node)+'_p-'+str(args.nb_processors)+'_sf-'+str(args.size_fast)+'_bf-'+str(args.bandwidth_fast)+'_ccr-'+str(args.ccr)
	# Create output directory (if not specified it's a 'build/' into the src directory)

	default_ouput = os.path.join(args.output_dir, os.path.basename(args.dot_dir), name_exp)
	if not os.path.exists(default_ouput):
		os.makedirs(default_ouput)

	print_args(args, os.path.join(default_ouput, 'configuration.sim'))

	output_csv_general = open(default_ouput+'/gather_'+name_exp+'.csv', newline='', mode='w')
	general_csv_writer = csv.writer(output_csv_general, delimiter=',',
									quotechar='|', 
									quoting=csv.QUOTE_MINIMAL)
	general_csv_writer.writerow(['DAG', 'N', 'P', 'BF', 'SF', 'SPEED', 'CCR', 'HEURISTIC', 'MKSP', 'MEDIAN', 'STDEV', 'AVG'])

	list_dotfiles = fnmatch.filter(os.listdir(args.dot_dir), '*.dot')

	with open(os.path.join(default_ouput, 'dataset.sim'), 'w') as f:
		for dot in list_dotfiles:
			f.write('{}\n'.format(os.path.join(args.dot_dir, dot)))

	best_gain = {}
	all_mksp = [] #Contain all makespan for each dot and for each iteration
	k = 0 # iterate on dot
	for dot in list_dotfiles:
		start_time_it = timer()
		i = 0
		dag_name = os.path.splitext(dot)[0]
		name_exp = dag_name+'_n-'+str(nb_node)+'_p-'+str(args.nb_processors)+'_sf-'+str(args.size_fast)+'_bf-'+str(args.bandwidth_fast)+'_ccr-'+str(args.ccr)
		all_mksp.append([])
		for iteration in range(args.nb_run_start, args.nb_run):
			theseed = iteration
			all_mksp[k].append([])

			H = nx.nx_agraph.read_dot(path=os.path.join(args.dot_dir, dot))
			G = nx.DiGraph()
			G.add_nodes_from(H.nodes(data=False))
			G.add_edges_from(H.edges(data=False))


			baseline_bandwith=90.0*1e9 # Bandwidth slow in B/s

			simu = sim.Simulation(
				name=name_exp,
				ggen=None,
				graph=G,
				proc=args.nb_processors, 
				speed=args.processor_speed, 
				size_fast=args.size_fast,
				bandwidth_fast=args.bandwidth_fast*baseline_bandwith,
				bandwidth_slow=1.0*baseline_bandwith, 
				seed=theseed,
				dotfile=True
			)

			# name_heuristics = []
			# for hproc in simu.__proc_heuristics__:
			# 	for hmem in simu.__mem_heuristics__:
			# 		name_heuristics.append(hproc.__name__.upper()+'+'+hmem.__name__.upper())

			#Create csv file for results
			csvfile = default_ouput+'/'+name_exp+'_seed-'+str(theseed)+'.csv'
			output_csv = open(csvfile, newline='', mode='w')
			spamwriter = csv.writer(
				output_csv, delimiter=',',
				quotechar='|', 
				quoting=csv.QUOTE_MINIMAL)

			#Compute the name of all heuristics used in this order (the order is important)
			proc_name = list(map(lambda x: str(x.__name__).upper(), simu.__proc_heuristics__))
			mem_name = list(map(lambda x: str(x.__name__).upper(), simu.__mem_heuristics__))
			name_heuristics = list(itertools.product(proc_name, mem_name))
			name_heuristics = ["CP+NO_FAST"]+["CP+CC_MODE"]+["CP+INF_FAST"]+["CP+INFFAST_INFBF"]+list(map(lambda x: x[0]+'+'+x[1], name_heuristics))
			#name_heuristics = ["CP+NO_FAST"]+["CP+CC_MODE"]+list(map(lambda x: x[0]+'+'+x[1], name_heuristics))
			#name_heuristics = list(map(lambda x: x[0]+'+'+x[1], name_heuristics))
			spamwriter.writerow(['DAG', 'ITER', 'SEED', 'N', 'P', 'BF', 'SF', 'SPEED', 'CCR', 'HEURISTIC', 'MKSP'])

			# if args.verbose >= 1 and iteration==0:
			# 	print (simu, "\n")

			# We initialize the DAG attributes (w, e and n) with random between bounds 
			# with  w -> the work w_i for each node
			# 		e -> e_ij the number of blocks for each edge
			# 		n -> n_ij the number of read for blocks e_ij
			simu.set_seed(theseed)

			#CCR is the computation/communication ratio
			#job are around 10e-3 sec (micro) to 10e-6 (milli) sec
			# args.size_fast # nb block en Byte tq le graph rentre pas dnas la Sf

			# def f(w_s,w_e,s,b,ccr):
			# 	return [ (w_s*b)/(s*ccr),(w_e*b)/(s*ccr)]

			w_start = math.floor(args.work_nodes[0]*args.processor_speed)
			w_end = math.floor(args.work_nodes[1]*args.processor_speed)
			e_start = math.floor((w_start*baseline_bandwith)/(args.ccr*args.processor_speed))
			e_end = math.floor((w_end*baseline_bandwith)/(args.ccr*args.processor_speed))
			simu.initialize_random(
				start_w=w_start, stop_w=w_end,
				start_e=e_start, stop_e=e_end,
				start_n=1, stop_n=1
			)

			if args.verbose >= 2:
				print ("{:>3} | W_s={} W_e={}, E_s={} E_e={}".format(iteration+1, w_start, w_end, e_start, e_end) )

			if not args.print_graphs:
				output_dot = default_ouput+'/graph_'+name_exp+'_seed-'+str(theseed)+'.dot'
				output_pdf = default_ouput+'/graph_'+name_exp+'_seed-'+str(theseed)+'.pdf'
				if args.verbose >= 2:
					print("Writing dot file... ", output_dot)
				nx.nx_agraph.write_dot(simu.graph, output_dot)
				#drawing_dag.draw(G, output_pdf)

			if args.verbose >= 2:
				print("Computing critical paths...")
			simu.compute_cp()
			if args.verbose >= 2:
				print("Starting simulations...")
			res = []
			cte = [nb_node, args.nb_processors, args.bandwidth_fast, args.size_fast, args.processor_speed, args.ccr]
			
			#Compute the performance without slow memory
			S = simu.schedule_0fastmem(args.verbose)
			res.append(str(simu.mksp(S)))
			all_mksp[k][i].append(simu.mksp(S))

			#Compute the cache mode baseline
			S = simu.schedule_as_cache_mode(args.verbose)
			res.append(str(simu.mksp(S)))
			all_mksp[k][i].append(simu.mksp(S))

			#Compute the performance with infinite fast memory
			S = simu.schedule_inffastmem(args.verbose)
			res.append(str(simu.mksp(S)))
			all_mksp[k][i].append(simu.mksp(S))

			#Compute the performance with infinite fast memory and infinite bandwidth
			S = simu.schedule_inffastmem_infbandwith(args.verbose)
			res.append(str(simu.mksp(S)))
			all_mksp[k][i].append(simu.mksp(S))

			#All heuristics
			for hproc in simu.__proc_heuristics__:
				for hmem in simu.__mem_heuristics__:
					#name_heuristics.append(hproc.__name__.upper()+'+'+hmem.__name__.upper())
					# We compute the schedule according an scheduling heuristic and a memory allocation heuristic
					S = simu.schedule_no_tr(hproc, hmem, args.verbose)
					#print("{:<30} {}".format(hproc.__name__.upper()+'+'+hmem.__name__.upper(), simu.mksp(S)))
					#print(" Makespan\t = ", simu.mksp(S), " (",simu.cp('0'),")")
					res.append(str(simu.mksp(S)))
					all_mksp[k][i].append(simu.mksp(S))
				#end for hmem
			#end for hproc

			#ITERATION = SEED here
			for j in range(len(name_heuristics)):
				spamwriter.writerow([os.path.splitext(dot)[0]]+[iteration, theseed]+cte+[name_heuristics[j], all_mksp[k][i][j]])
			
			i = i + 1 #iteration

		#end for iteration
		output_csv.close()

		#gather all makespan from each iteration for H1 to first sublist, for H2 for second sublist etc
		#print(mksp)
		mksp_res = [[item[i] for item in all_mksp[k]] for i in range(len(all_mksp[k][0]))]
		res_final = list(zip(map(mean, mksp_res), map(median, mksp_res), map(stdev, mksp_res)))

		x = 0
		min_res = math.inf
		max_res = 0
		min_id = -1
		max_id = -1
		for i in range(len(res_final)):
			if res_final[i][0] < min_res:
				min_res=res_final[i][0]
				min_id=i
			if res_final[i][0] > max_res:
				max_res=res_final[i][0]
				max_id=i
		best_gain[dag_name] = (name_heuristics[min_id], name_heuristics[max_id], (res_final[max_id][0]-res_final[min_id][0])*100/res_final[max_id][0])

		end_time_it = timer()
		if args.verbose >= 2:
			print('{:<30} {:<20} {:<20} {:<20}'.format("HEURISTIC", "MEAN", "MEDIAN", "STDEV"))
			for h in res_final:
				percentage_stdev = (h[2]/h[0])*100
				if min_id == x:
					print('{}{:<30} {:<20} {:<20} {:<20} ({:2.2f}%){}'.format(utils.colors.okgreen+utils.colors.bold,name_heuristics[x],*h,percentage_stdev,utils.colors.endc))
				elif max_id == x:
					print('{}{:<30} {:<20} {:<20} {:<20} ({:2.2f}%){}'.format(utils.colors.fail+utils.colors.bold,name_heuristics[x],*h,percentage_stdev,utils.colors.endc))
				else:
					print('{:<30} {:<20} {:<20} {:<20} ({:2.2f}%)'.format(name_heuristics[x],*h,percentage_stdev))
				x = x + 1

		print("{}[{:8.2f}]{}{} Best gain for {}: {:5.2f}% with {:<30} over {:<30} {}".format(utils.colors.warning, end_time_it-start_time_it, utils.colors.endc, utils.colors.bold, dag_name, best_gain[dag_name][-1], best_gain[dag_name][0], best_gain[dag_name][1], utils.colors.endc))

		#'DAG', 'N', 'P', 'BF', 'SF', 'SPEED', 'CCR', 'HEURISTIC', 'MKSP', 'MEDIAN', 'STDEV', 'AVG'
		for j in range(len(name_heuristics)):
			general_csv_writer.writerow(['stg_'+dag_name]+cte+[name_heuristics[j],res_final[j][0],res_final[j][1],res_final[j][2],args.nb_run])
		k = k + 1
	#end for dot file
	output_csv_general.close()


	#gather all makespan to compute average, median, stdev
	mksp_res = []
	for j in range(len(all_mksp[0][0])):
		mksp_res.append([])

	for k in range(len(all_mksp)):
		for i in range(len(all_mksp[k])):
			for j in range(len(all_mksp[k][i])):
				mksp_res[j].append(all_mksp[k][i][j])

	# print(all_mksp)
	# print(mksp_res)
	# for j in range(len(heuristic)):
	# 	print(heuristic[j], mksp_res[j])

	res_final = list(zip(map(mean, mksp_res), map(median, mksp_res), map(stdev, mksp_res)))

	print('{:<30} {:<20} {:<20} {:<20}'.format("HEURISTIC", "MEAN", "MEDIAN", "STDEV"))
	x = 0
	min_res = math.inf
	max_res = 0
	min_id = -1
	max_id = -1
	for i in range(len(res_final)):
		if res_final[i][0] < min_res:
			min_res=res_final[i][0]
			min_id=i
		if res_final[i][0] > max_res:
			max_res=res_final[i][0]
			max_id=i

	for h in res_final:
		percentage_stdev = (h[2]/h[0])*100
		if min_id == x:
			print('{}{:<30} {:<20} {:<20} {:<20} ({:2.2f}%){}'.format(utils.colors.okgreen+utils.colors.bold,name_heuristics[x],*h,percentage_stdev,utils.colors.endc))
		elif max_id == x:
			print('{}{:<30} {:<20} {:<20} {:<20} ({:2.2f}%){}'.format(utils.colors.fail+utils.colors.bold,name_heuristics[x],*h,percentage_stdev,utils.colors.endc))
		else:
			print('{:<30} {:<20} {:<20} {:<20} ({:2.2f}%)'.format(name_heuristics[x],*h,percentage_stdev))
		x = x + 1



#@utils.timing
def main_one_file(args):
	if args.verbose == None:
		args.verbose = -1
	if args.dot_file:
		name_exp = 'dotfile_n-'+str(args.nb_nodes)+'_p-'+str(args.nb_processors)+'_sf-'+str(args.size_fast)+'_bf-'+str(args.bandwidth_fast)
	else:
		name_exp = 'random_n-'+str(args.nb_nodes)+'_p-'+str(args.nb_processors)+'_sf-'+str(args.size_fast)+'_bf-'+str(args.bandwidth_fast)
	# Create output directory (if not specified it's a 'build/' into the src directory)
	if args.output_dir:
		default_ouput = args.output_dir+'/build_'+name_exp
	else:
		default_ouput = args.output_dir

	if args.output_dir and not os.path.exists(default_ouput):
		os.makedirs(default_ouput)

	mksp = []
	i = 0
	if args.dot_file:
		is_dote_file = True

	for iteration in range(args.nb_run_start, args.nb_run):
		mksp.append([])

		if args.dot_file:
			H = nx.nx_agraph.read_dot(path=args.dot_file)
			G = nx.DiGraph()
			G.add_nodes_from(H.nodes(data=False))
			G.add_edges_from(H.edges(data=False))
		else:
			G = nx.fast_gnp_random_graph(
				n=args.nb_nodes, 
				p=0.005, 
				seed=iteration,
				directed=True)
			G.remove_edges_from([(u,v) for (u,v) in G.edges() if u>=v])
		
		simu = sim.Simulation(
			name=name_exp,
			ggen=None,
			graph=G,
			proc=args.nb_processors, 
			speed=args.processor_speed, size_fast=args.size_fast, 
			bandwidth_fast=args.bandwidth_fast, 
			bandwidth_slow=1.0, 
			seed=iteration,
			dotfile=is_dote_file
		)

		name_heuristics = []
		for hproc in simu.__proc_heuristics__:
			for hmem in simu.__mem_heuristics__:
				name_heuristics.append(hproc.__name__.upper()+'+'+hmem.__name__.upper())

		#Create csv file for results
		csvfile = default_ouput+'/'+name_exp+'_'+str(iteration)+'.csv'
		output_csv = open(csvfile, newline='', mode='w')
		spamwriter = csv.writer(
			output_csv, delimiter=',',
			quotechar='|', 
			quoting=csv.QUOTE_MINIMAL)

		proc_name = list(map(lambda x: str(x.__name__).upper(), simu.__proc_heuristics__))
		mem_name = list(map(lambda x: str(x.__name__).upper(), simu.__mem_heuristics__))
		heuristic = list(itertools.product(proc_name, mem_name))
		heuristic = list(map(lambda x: x[0]+'+'+x[1], heuristic))
		spamwriter.writerow(['ITER', 'SEED', 'N', 'P', 'BF', 'SF', 'SPEED', 'CCR']+heuristic)


		if args.verbose >= 1 and iteration==0:
			print (simu, "\n")

		# We initialize the DAG attributes (w, e and n) with random between bounds 
		# with  w -> the work w_i for each node
		# 		e -> e_ij the number of blocks for each edge
		# 		n -> n_ij the number of read for blocks e_ij
		simu.set_seed(iteration)

		#CCR is the computation communication ratio

		w_start = 1
		w_end = 10
		simu.initialize_random(
			start_w=w_start, stop_w=w_end,
			start_e=math.ceil(args.ccr*w_start), stop_e=math.ceil(args.ccr*w_end),
			start_n=1, stop_n=1
		)

		if args.verbose >= 1:
			print ("{:>3} | W_s={} W_e={}, E_s={} E_e={}".format(iteration+1, 10, 100, math.ceil(args.ccr*10), math.ceil(args.ccr*100)))

		if not args.print_graphs:
			output_dot = default_ouput+'/graph_'+name_exp+'_'+str(iteration)+'.dot'
			output_pdf = default_ouput+'/graph_'+name_exp+'_'+str(iteration)+'.pdf'
			if args.verbose >= 1:
				print("Writing dot file... ", output_dot)
			nx.nx_agraph.write_dot(simu.graph, output_dot)
			#drawing_dag.draw(G, output_pdf)

		if args.verbose >= 1:
			print("Computing critical paths...")
		simu.compute_cp()
		if args.verbose >= 1:
			print("Starting simulations...")
		res = []
		cte = [args.nb_nodes, args.nb_processors, args.bandwidth_fast, args.size_fast, args.processor_speed, args.ccr]
		for hproc in simu.__proc_heuristics__:
			for hmem in simu.__mem_heuristics__:
				name_heuristics.append(hproc.__name__.upper()+'+'+hmem.__name__.upper())
				# We compute the schedule according an scheduling heuristic and a memory allocation heuristic
				S = simu.schedule_no_tr(hproc, hmem, args.verbose)
				#print("{:<30} {}".format(hproc.__name__.upper()+'+'+hmem.__name__.upper(), simu.mksp(S)))
				#print(" Makespan\t = ", simu.mksp(S), " (",simu.cp('0'),")")
				res.append(str(simu.mksp(S)))
				mksp[i].append(simu.mksp(S))

		spamwriter.writerow([iteration, iteration]+ cte +res)
		i = i + 1

	#gather all makespan from each iteration for H1 to first sublist, for H2 for second sublist etc
	#print(mksp)
	mksp_res = [[item[i] for item in mksp] for i in range(len(mksp[0]))]
	res_final = list(zip(map(mean, mksp_res), map(median, mksp_res), map(stdev, mksp_res)))

	print('{:<30} {:<20} {:<20} {:<20}'.format("HEURISTIC", "MEAN", "MEDIAN", "STDEV"))
	x = 0

	min_res = math.inf
	max_res = 0
	min_id = -1
	max_id = -1
	for i in range(len(res_final)):
		if res_final[i][0] < min_res:
			min_res=res_final[i][0]
			min_id=i
		if res_final[i][0] > max_res:
			max_res=res_final[i][0]
			max_id=i

	for h in res_final:
		percentage_stdev = (h[2]/h[0])*100
		if min_id == x:
			print('{}{:<30} {:<20} {:<20} {:<20} ({:2.2f}%){}'.format(utils.colors.okgreen+utils.colors.bold,name_heuristics[x],*h,percentage_stdev,utils.colors.endc))
		elif max_id == x:
			print('{}{:<30} {:<20} {:<20} {:<20} ({:2.2f}%){}'.format(utils.colors.fail+utils.colors.bold,name_heuristics[x],*h,percentage_stdev,utils.colors.endc))
		else:
			print('{:<30} {:<20} {:<20} {:<20} ({:2.2f}%)'.format(name_heuristics[x],*h,percentage_stdev))
		x = x + 1

	print("\n{}Best gain: {:2.2f}% {}".format(utils.colors.bold, (res_final[max_id][0]-res_final[min_id][0])*100/res_final[max_id][0], utils.colors.endc))

if __name__ == "__main__":
	current_dir = os.getcwd()
	parser = argparse.ArgumentParser()
	parser.add_argument('-o', '--output-dir', type=str, nargs='?', default='build', required=False, help="Output directory (by default the current directory is used)")
	# parser.add_argument('-i', '--input', type=str, nargs='?', default=None, required=False, help="Input file containing all the parameters")
	parser.add_argument('-n', '--nb-nodes', type=int, nargs='?', default=None, required=False, help="Number of nodes in the random graph")
	parser.add_argument('--dot-file', type=str, nargs='?', default=None, required=False, help="Dot file to use as input")
	parser.add_argument('--dot-dir', type=str, nargs='?', default=None, required=False, help="Dot dir to use as input")

	parser.add_argument('-p', '--nb-processors', type=int, default=1, required=True, help="Number of processors")
	parser.add_argument('-b', '--bandwidth-fast', type=float, nargs='?', default=1.0, required=True, help="Fast bandwidth speed")
	parser.add_argument('--work-nodes', type=float, nargs=2, default=True, required=True, help="Work start and end")
	parser.add_argument('-c', '--size-fast', type=float, nargs='?', default=0, required=True, help="Fast memory size")
	parser.add_argument('-s', '--processor-speed', type=float, nargs='?', default=1.0, required=True, help="Processors speed")
	parser.add_argument('-v', '--verbose', type=int, nargs='?', default=-1, required=False, help="Verbose output [0,1,2,3]")
	parser.add_argument('-a', '--nb-run', type=int, nargs='?', default=1.0, required=True, help="Number of runs to average")
	parser.add_argument('--ccr', type=float, nargs='?', default=1.0, required=False, help="Computation/communication ratio")
	parser.add_argument('--nb-run-start', type=int, nargs='?', default=0, required=False, help="Staring number for average (and for seed)")
	parser.add_argument('--print-graphs', type=bool, nargs='?', default=True, required=False, help="Create graphs and Gantt charts (to output directory)")

	# parser.add_argument('-s', '--seed', type=int, nargs='?', default=0, required=False, help="The seed used by the random generator")

	# if len(sys.argv[1:]) == 0:
	# 	parser.print_help()
	# 	parser.exit()

	args = parser.parse_args()

	if args.dot_file is None and args.nb_nodes is None and args.dot_dir is None:
		parser.error("either --nb-nodes, --dot-file or --dot-dir is required.")

	if args.dot_file != None:
		dotfile = Path(args.dot_file)
		if not dotfile.exists():
			parser.error("{} file does not exist.".format(args.dot_file))

	if args.dot_dir != None:
		dotdir = Path(args.dot_dir)
		if not dotdir.exists():
			parser.error("{} file does not exist.".format(args.dot_dir))

	if args.nb_run_start is None:
		args.nb_run_start = 0

	if args.dot_dir != None:
		main(args)
	else:
		main_one_file(args)
